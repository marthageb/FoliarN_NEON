###################apply PLSR model coefficients (from PLSRloop.R) to hyperspectral readings for all locations soil was sampled (output from format_ref.R).
###################Before applying coefficients, calculate brightness normalization.
###################Also, compare predicted foliar N to measured foliar N
###############1st code for individual (single pixel) reflectance readings, the 3mbuffer area########

setwd("Z:/SRER/Martha/Rfdata")

#load reflectance vals from all soil smaple locations (output from "format_ref.R")
refall <- read.csv("./ref/ref_all.csv")

#################pre-processing of the reflectance data###################
#brightness normalization per Feilhauer et al 2010
ref <- refall[,3:428]
ref <- as.matrix(ref)
#create the brightness normalized function
bnorm <- function (X)
{ X <- X / sqrt (rowSums (X ^ 2))}
#apply the brightness normalized function
bnref <- bnorm(ref)

################loading PLSR coefficient values -- output from PLSRloop.R code###########
#load the averaged coeff values from robust models with no spatial auto correlation
coef <- read.csv("c:/Users/marthag/Desktop/envi_spectralJan2020/PlotLOO_avggoodcoeff.csv")
#get the averaged y-intercept value
intcpt <- coef[1,2]
str(intcpt)

#get all wavelengths (including ones that are excluded from PLSR model)
wave <- as.data.frame(colnames(refall[,3:428]))
wave <- as.data.frame(substring(wave[,1], 5))
names(wave)[names(wave)== "substring(wave[, 1], 5)"] <- "lambda"
wave$lambda <- as.numeric(wave$lambda)

#subset coefficient values
coefref <- coef[-1,]
names(coefref)[names(coefref)== "X"] <- "lambda"
names(coefref)[names(coefref)== "V1"] <- "reflectance"
coefref$lambda <- as.numeric(coefref$lambda)

#merge two dataframe keeping all wavelengths values
coefall <- merge(wave, coefref, by="lambda", all.x=TRUE)
coefall$lambda <- as.numeric(coefall$lambda)
#replace NA values with 0s
coefall$reflectance[is.na(coefall$reflectance)] = 0

########################Apply PLSR coefficients to reflectance values to predict foliar N#############
mult <-  matrix(NA, nrow=nrow(ref), ncol=ncol(ref))

#multiply each wavelength by the coefficient value
for (i in 1:426){
  coeff <- coefall[i,2]
  mult[,i] <- ref[,i] * coeff}

#calcualte rowsums for all multiplied values
refall$sum <- apply(mult, 1, sum)
refall$Npred <- refall$sum + intcpt
npred <- refall[,c(2,430,1)]

write.csv(npred, "PLSRpredN.csv")

#############load measured foliar N values and compare to predicted values#############
foliarchem <- read.csv("foliarchem.csv")
chem <- aggregate(perN ~ foliarNID, foliarchem, mean)

chem <- merge(chem, npred, by="foliarNID")


# Build the model
model <- lm(perN ~ Npred, data = chem)
# Summarize the model
summary(model)

####compare to plot level foliar N values used in PLSR model building####
Nref <- read.csv("c:/Users/marthag/Desktop/envi_spectralJan2020/hyperspec_foliarN.csv")
Nref1 <- Nref[,2:3]
Nref1 <- aggregate(Nref1, by=list(Nref1$ID), FUN=mean)

#change sampleIDS to having the 1st letter capitilized (to match with sampleIDs on rasdata)
CapStr <- function(y) {
  c <- strsplit(y, " ")[[1]]
  paste(toupper(substring(c, 1,1)), substring(c, 2),
        sep="", collapse=" ")
}
#change IDs to uppercase and remove replicate numbers to match Nref dataframe
npred$IDs <- sapply(npred$foliarNID, CapStr)
npred$IDs <- gsub("1.2$", "", npred$IDs)
npred$IDs <- gsub("2.2$", "", npred$IDs)
#remove bare, drip, midd observations  
npred1 <- npred[!(npred$foliarNID==""),]

npred1 <- aggregate(npred1, by=list(npred1$IDs), FUN=mean)
npred1 <- npred1[,c(1,4)]

regdata <- merge(Nref1, npred1, by="Group.1")

# Build the model
model <- lm(plotN ~ Npred, data = regdata)
# Summarize the model
summary(model)

##################################################################################
############################Apply PLSR to 3m buffer area##########################
##################################################################################
setwd("Z:/SRER/Martha/Rfdata")

#load reflectance vals from all soil smaple locations (output from "format_ref.R")
refall <- read.csv("3mbuff_points.csv")
#replace -9999 values with NA
refall[refall==-9999.0000	] <- NA

refagg <- refall[,-c(1,3,4,431,432)]
refagg <- aggregate(refagg, by=list(refagg$id), FUN=mean)
refagg$id <- refagg$Group.1
refagg <- refagg[,-1]

#################pre-processing of the reflectance data###################
#brightness normalization per Feilhauer et al 2010
ref <- refagg[,2:427]
ref <- as.matrix(ref)
#create the brightness normalized function
bnorm <- function (X)
{ X <- X / sqrt (rowSums (X ^ 2))}
#apply the brightness normalized function
bnref <- bnorm(ref)

################loading PLSR coefficient values -- output from PLSRloop.R code###########
#load the averaged coeff values from robust models with no spatial auto correlation
coef <- read.csv("c:/Users/marthag/Desktop/envi_spectralJan2020/PlotLOO_avggoodcoeff.csv")
#get the averaged y-intercept value
intcpt <- coef[1,2]
str(intcpt)

#get all wavelengths (including ones that are excluded from PLSR model)
#for some reason the wavelengths on the 3mbuff reflectance data set don't merge correctly w the PLSR coeffs, so use the wavelengtsh from the old reflectance dataset
refall2 <- read.csv("./ref/ref_all.csv")
#get all wavelengths (including ones that are excluded from PLSR model)
wave <- as.data.frame(colnames(refall2[,3:428]))
wave <- as.data.frame(substring(wave[,1], 5))
names(wave)[names(wave)== "substring(wave[, 1], 5)"] <- "lambda"
wave$lambda <- as.numeric(wave$lambda)

#subset coefficient values
coefref <- coef[-1,]
names(coefref)[names(coefref)== "X"] <- "lambda"
names(coefref)[names(coefref)== "V1"] <- "coef"
coefref$lambda <- as.numeric(coefref$lambda)

#merge two dataframe keeping all wavelengths values
coefall <- merge(wave, coefref, by="lambda", all.x=TRUE)
coefall$lambda <- as.numeric(coefall$lambda)
#replace NA values with 0s
coefall$coef[is.na(coefall$coef)] = 0

########################Apply PLSR coefficients to reflectance values to predict foliar N#############
mult <-  matrix(NA, nrow=nrow(ref), ncol=ncol(ref))

#multiply each wavelength by the coefficient value
for (i in 1:426){
  coeff <- coefall[i,2]
  mult[,i] <- bnref[,i] * coeff}

#calcualte rowsums for all multiplied values
refagg$sum <- apply(mult, 1, sum)
refagg$Npred <- refagg$sum + intcpt
npred <- refagg[,c(1,429)]

write.csv(npred, "./3mbuff/PLSRpredN.csv")


###write aggregated reflectance vals w good column names
reff <- refagg[,-c(428:429)]
correctlambda <- c("ID",colnames(refall2[,3:428]))
colnames(reff) <- correctlambda

write.csv(reff, "./3mbuff/ref_3mbuff.csv")


##########compare to other foliar N measures##############
refpoint<- read.csv("./ref/ref_all.csv")
CapStr <- function(y) {
  c <- strsplit(y, " ")[[1]]
  paste(toupper(substring(c, 1,1)), substring(c, 2),
        sep="", collapse=" ")
}
refpoint$ID <- sapply(refpoint$sampleID, CapStr)
IDs <- refpoint[,c(429,1)]

npred2 <- merge(IDs, npred, by.x="ID", by.y="id")

foliarchem <- read.csv("foliarchem.csv")
chem <- aggregate(perN ~ foliarNID, foliarchem, mean)

chem <- merge(chem, npred2, by="foliarNID")


# Build the model
model <- lm(perN ~ Npred, data = chem)
# Summarize the model
summary(model)
