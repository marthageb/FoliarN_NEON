library(ggplot2)
library(grid)
library(extrafont)
library(multcompView)
#font_import()
#loadfonts(device="win")    

setwd("C:/Users/farellam/Documents/FoliarN_NEON/data")
#load ref data for all plant clip locations
data <- read.csv("oldanalysis.csv")

##########REFLECTANCE GRAPHS############
#rename columns from band# to wavelength
ref <- data[,28:453]
#create wavelengths for bands
lambda <- seq(385,2510, by=5)
lambda <- sub("$", "nm", lambda) 
colnames(ref) <- lambda


#if subsetting x biome
#biome <- subset(data, ntrgnPr > 2.470 )
biome <- subset(data, biome=="Continental")
ref <- biome[,28:453] #if subsetting x biome

#shortest, longest, and water abosrption bands as NA
ref[,1:5] <- NA
ref[,191:215] <- NA
ref[,283:324] <- NA
ref[,413:426] <- NA

#calcualte avg reflectance
avgref <- as.data.frame(colMeans(ref, na.rm=TRUE))
avgref$band <-  seq(385,2510, by=5)
names(avgref)[names(avgref)=="colMeans(ref, na.rm = TRUE)"] <- "avgref"

#calculate reflectance sd for each band
sdref <- as.data.frame(apply(ref,2,sd, na.rm=TRUE))

avgref <- cbind.data.frame(avgref, sdref)
names(avgref)[names(avgref)=="apply(ref, 2, sd, na.rm = TRUE)"] <- "sdref"

avgref$lower <- avgref$avgref - avgref$sdref
avgref$upper <- avgref$avgref + avgref$sdref
avgref$issue <- avgref$sdref > avgref$avgref

windowsFonts(A=windowsFont("Calibri Light"))

#all sites col="#696969
#temperate col="#37BE81"
#arid col="#fecb34"
#continental col="#326186"
#tropical col="#d14d28"
setwd("C:/Users/farellam/Documents/FoliarN_NEON/Results/")
tiff('Fig1ref_all.tif', units="in",  width = 5.2, height = 4.2, res=300, compression = 'lzw')

eb <- aes(ymax = upper, ymin = lower)
plot1 <- ggplot(data = avgref, aes(x = band , y = avgref)) + 
  ylim(0,0.6) +
  geom_line(size = 1, color="#696969") + 
  geom_ribbon(eb, fill="#696969", alpha=0.5)+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) + #for no background or grid
  labs(y = "Reflectance", x="Wavelength (nm)") +
  theme(text=element_text(size=20,  family="A", color="black")) +
  theme(axis.text=element_text(color="black"))+
  theme(plot.title = element_text(hjust = 0.5, vjust=-5, family="A")) +
  labs(title=NULL)

site <- grobTree(textGrob("All Sites", x=0.13,  y=0.95,
                          gp=gpar(fontfamily ="A", fontsize=20)))
plot1 + annotation_custom(site)  

dev.off()

#########BOX PLOT##########
#convertdescriptive variables to factor vars
data$PFTacro <- as.factor(data$PFTacro)
data$ClimateClass <- as.factor(data$ClimateClass)
data$fixN <- as.factor(data$fixN)
data$PFT <- as.factor(data$PFT)
data$siteID <- as.factor(data$siteID)
data$biome <- as.factor(data$biome)

aov1 <- aov(ntrgnPr ~ biome, data)
summary(aov1)
print(model.tables(aov1, "means", se=T))
tuk1 <- TukeyHSD(aov1)
multcompLetters4(aov1, tuk1)

#reoder the biome groups order
data$biome <- factor(data$biome, levels=c("Temperate", "Arid", "Continental", "Tropical"))

#set the plot margin
par(mar=c(2.25,3.7,0,0))

#change the font 
windowsFonts(A = windowsFont("Calibri Light"))
setwd("C:/Users/farellam/Documents/FoliarN_NEON/Results/")
#create the boxplot
tiff('Fig1boxplot.tif', units="in",  width = 6.75, height = 5.2, res=300, compression = 'lzw')
par(mar=c(2.25,3.7,0,0))
boxplot(ntrgnPr ~ biome, data, col=c("#37be81", "#fecb34", "#326186", "#d14d28"), 
        xaxt="n", ylim=c(0,4.7), yaxt="n", ylab="", xlab="", family="A")
axis(1, at=c(1,2,3,4), labels=c("Temperate", "Arid", "Continental", "Tropical"), family="A", cex.axis=1.75)
axis(2, at=c(0,1,2,3,4), labels=c("0", "1", "2", "3", "4"), family="A", cex.axis=1.75)
title(ylab="Foliar N (%)", line=2.3, family="A", cex.lab=1.75)
text(1,4.7, labels="b", family="A", cex=1.5)
text(2,3.7, labels="a", family="A", cex=1.5)
text(3,3.9, labels="c", family="A", cex=1.5)
text(4,4.1, labels="ab", family="A", cex=1.5)
text(3.6,0.1, labels=substitute(paste(italic("F = 8.28; p = 2.11 x 10"^"-5"))), family="A", cex=1.5)

dev.off()
