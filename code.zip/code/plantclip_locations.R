library(dplyr)

#############
#Load field sampled foliarN data
options(stringsAsFactors=F)
#set working directory
setwd("XXXX")
#load foliar chemistry data downloaded with "download_data.R" code
foliar <- read.csv("./data/filesToStack10026/stackedFiles/cfc_carbonNitrogen.csv")
#load field metadata
fielddata <- read.csv("./data/filesToStack10026/stackedFiles/cfc_fieldData.csv")

# remove analytical duplicates wherever they exist. take means for numeric variables, else first observation. 
foliarchem <- foliar %>%
  group_by(cnSampleID) %>%
  summarise_all(list( ~ if (is.numeric(.)) {
    mean(., na.rm = TRUE)
  } else {
    first(.)
  }))

#trim columns
foliarchem <- foliarchem[,c(8,3:6,11, 14:16)]
fielddata2 <- fielddata[,c(32,7,17,22,27,24)]

#merge datasets
foliarN <- merge(foliarchem, fielddata2, by="sampleID")
#write.csv(foliarN, "allsamples_foliarchem.csv")

#subset herbaceous samples
foliarN$sampleType <- as.factor(foliarN$sampleType)
Nherbs <- subset(foliarN, sampleType == "Herbaceous clip strip")

#subset woody individuals
Nwoody <- subset(foliarN, sampleType == "Woody individual")

###############HERB CLIP SAMPLES##################
#get locations of herb clip samples 
#https://github.com/NEONScience/NEON-geolocation/tree/master/geoNEON
library(neonUtilities)

devtools::install_github('NEONScience/NEON-geolocation/geoNEON')

library(geoNEON)
#cfc <- loadByProduct('DP1.10026.001', packag='expanded')
#cfc.loc <- getLocTOS(cfc$cfc_fieldData, 'cfc_fieldData')

fielddata <- read.csv("./data/filesToStack10026/stackedFiles/cfc_fieldData.csv")
cfc.loc <- getLocTOS(fielddata, 'cfc_fieldData')

herbs <- subset(cfc.loc, sampleType == "Herbaceous clip strip")

#select 
herbs_loc <- herbs[,c(28:31,45:47,49:50)]

herbsN_loc <- merge(Nherbs,herbs_loc, by="clipID")
write.csv(herbsN_loc, "herbs_foliarchem_locations.csv")


################WOODY CLIP SAMPLES###################
#get locations of woody samples (sections 1 & 2):https://www.neonscience.org/tree-heights-veg-structure-chm
library(sp)
library(raster)
library(neonUtilities)
library(geoNEON)

#Download the vegetation structure data using the loadByProduct() function in the neonUtilities package. Inputs needed to the function are:
## dpID: data product ID; woody vegetation structure = DP1.10098.001
veglist <- loadByProduct("DP1.10098.001", package="basic")

#Filter to only the individualIDs that appear in the foliar data
woody <- subset(veglist$vst_mappingandtagging, individualID %in% Nwoody$individualID)

#Use the def.calc.geo.os() function in the geoNEON package to get precise locations for the tagged plants. Refer to the package documentation for more details.
vegmap <- def.calc.geo.os(woody, "vst_mappingandtagging")

woody_loc <- vegmap[,c(2,20,31,32,33,35,36)]
woodyN_loc <- merge(Nwoody, woody_loc, by="individualID")

#identify any repeate individual IDs
woodyN_loc$individualID[duplicated(woodyN_loc$individualID)]

# remove duplicate values wherever they exist due to repeate mapping and tagging over time.
# take means for numeric variables, else first observation. 
woodylocs <- woodyN_loc %>%
  group_by(sampleID) %>%
  summarise_all(list( ~ if (is.numeric(.)) {
    mean(., na.rm = TRUE)
  } else {
    first(.)
  }))


write.csv(woodylocs, "woody_foliarchem_locations.csv")
