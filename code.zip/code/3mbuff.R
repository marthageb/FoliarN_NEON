#################################################################################
###########create 3m rectangle buffer around plant sample locations##############
#################################################################################
#####code adopted from: https://www.neonscience.org/field-data-polygons-centroids
library(sp)
library(rgdal)
library(raster)

#setwd
setwd("XXXX")
#load plant clip locations
plantclips <- readOGR("./data/dataSept2020/shp_files", "zone19N")
samples <- as.data.frame(plantclips)
samples$siteID <- as.factor(samples$siteID)
summary(samples$siteID)

#load SRER plot centroids
#plantclips <- readOGR("Z:/SRER/Martha/arcGIS/plots/plotcentroids.shp")
#plantclips$type <- substr(plantclips$siteID, 3,7)
#plantclips <- subset(plantclips, type %in% c("grass", "mesq"))
#samples <- as.data.frame(plantclips)

#set the radius for the plots 1.5 would be a 3 x 3 buffer
radius <- 1.5
#define the plot edges based upon the plot radius. 
##"coords.x1" is the adjEasting coordinate
##"coords.x2" is the adjNorthing coordinate
yplus <- samples$coords.x2 + radius
xplus <- samples$coords.x1 + radius
yminus <- samples$coords.x2 - radius
xminus <- samples$coords.x1 - radius

# calculate polygon coordinates for each plot centroid. 
square=cbind(xminus,yplus,  # NW corner
             xplus, yplus,  # NE corner
             xplus,yminus,  # SE corner
             xminus,yminus, # SW corner
             xminus,yplus)  # NW corner again - close ploygon

# Extract the sample ID information
ID=samples$samplID
# extract site ID
siteID <- samples$siteID

#FOR SRER:
#ID <- samples$siteID
#siteID <- rep("SRER", 30)

# create spatial polygons from coordinates, set the crs to "plantclips" spatialpoints dataframe 
polys <- SpatialPolygons(mapply(function(poly, id) 
{
  xy <- matrix(poly, ncol=2, byrow=TRUE)
  Polygons(list(Polygon(xy)), ID=id)
}, 
split(square, row(square)), ID),
proj4string=crs(plantclips))


# Create SpatialPolygonDataFrame -- this step is required to output multiple polygons.
polys.df <- SpatialPolygonsDataFrame(polys, data.frame(id=ID, row.names=ID))

#add siteID to the polygon spatial dataframe whenever "samplID" matches
polys.df$siteID <- samples$siteID[match(polys.df$id, samples$samplID)]


polys2 <- as.data.frame(polys.df)

# write the shapefiles 
writeOGR(polys.df, './AOPreflectance/3mbuff', 'SRER', 'ESRI Shapefile', overwrite_layer = TRUE)

