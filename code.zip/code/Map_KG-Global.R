###########################################################################################
##
## R source code to read and visualize Köppen-Geiger fields (Version of 27 December 2019)                                                                                    
##
## Climate classification after Kottek et al. (2006), downscaling after Rubel et al. (2017)
##
## Kottek, M., J. Grieser, C. Beck, B. Rudolf, and F. Rubel, 2006: World Map of the  
## Köppen-Geiger climate classification updated. Meteorol. Z., 15, 259-263.
##
## Rubel, F., K. Brugger, K. Haslinger, and I. Auer, 2017: The climate of the 
## European Alps: Shift of very high resolution Köppen-Geiger climate zones 1800-2100. 
## Meteorol. Z., DOI 10.1127/metz/2016/0816.
##
## (C) Climate Change & Infectious Diseases Group, Institute for Veterinary Public Health
##     Vetmeduni Vienna, Austria
##
##code adapted from: http://koeppen-geiger.vu-wien.ac.at/present.htm
###########################################################################################
setwd("D:/martha/NEONpaper/KG_Climate_Class/")

# required packages 
library(raster); library(rasterVis); library(rworldxtra); data(countriesHigh)
library(rgdal); library(dplyr)

#load KG climate classifications
#setwd("Z:/SRER/Martha/NEONpaper/KG_Climate_Class")
#read raster file
period='1986-2010'
r <- raster(paste('KG_', period, '.grd', sep=''))
#writeRaster(r, "KGraster.img")
#load plant clip locations, convert to spatial points and define projection
setwd("C:/Users/farellam/Documents/FoliarN_NEON/data/")
data <- read.csv("foliarchem_locs_allsites.csv")
coordinates(data)= ~ adjDecimalLongitude + adjDecimalLatitude
proj4string(data) <- proj4string(r)
#extract climate classes from KG Classifications for all plant clip locations
CC <- raster::extract(r, data, df=T)
data$IDs <- row.names(data)


#CREATE LOOKUP TABLE TO DEFINE CLIMATE CLASSIFICATIONS EXTRACTED
# Legend must correspond to all climate classes, insert placeholders
r0 <- r[1:32]; r[1:32] <- seq(1,32,1)
# Converts raster field to categorical data
r <- ratify(r); rat <- levels(r)[[1]]
# Legend is always drawn in alphabetic order
rat$climate <- c('Af', 'Am', 'As', 'Aw', 'BSh', 'BSk', 'BWh', 'BWk', 'Cfa', 'Cfb','Cfc', 'Csa', 'Csb', 'Csc', 'Cwa','Cwb', 'Cwc', 'Dfa', 'Dfb', 'Dfc','Dfd', 'Dsa', 'Dsb', 'Dsc', 'Dsd','Dwa', 'Dwb', 'Dwc', 'Dwd', 'EF','ET', 'Ocean')
# Remove the placeholders
r[1:32] <- r0; levels(r) <- rat

#amend df to have lettered climate classifications
new <- CC
new$climate <- rat$climate[match(unlist(CC$layer), rat$ID)]
CCdata <- merge(new,data, by.x="ID", by.y="IDs")
ccdata <- CCdata[,(-c(1,2,4))]
ccdata$KG_CC <- rep("Temperate", nrow=nrow(ccdata)) 
ccdata$KG_CC[ccdata$climate %in% c("Dfb", "Dfc")] <- "Continental"
ccdata$KG_CC[ccdata$climate %in% c("BSk", "BWk")] <- "Arid"
ccdata$KG_CC[ccdata$climate %in% c("Aw")] <- "Tropical"
ccdata$KG_CC[ccdata$climate %in% c("ET")] <- "Polar"
write.csv(ccdata, "Climate_class.csv")
getwd()


#make a column IDing training/testing sites
ccdata$type <- rep("training", nrow=nrow(CC))
ccdata$type[ccdata$siteID %in% c("BONA", "JERC", "NIWO", "WREF")] <- "testing"

#get number of each climate classification x site
summ <- ccdata %>% group_by(siteID, climate) %>% summarize(num=n())
#get total number of observations for each cliamte classification
totalN <- ccdata %>% group_by(KG_CC, type) %>% summarize(num=n())



#####SRER SAMPLES#######
setwd("Z:/SRER/Martha/NEONpaper/KG_Climate_Class")
#read raster file
period='1986-2010'
r <- raster(paste('KG_', period, '.grd', sep=''))

#read plot centroids shp file
setwd("Z:/SRER/Martha/arcGIS/plots")
plotcenter <- read_sf("plotcentroids.shp")
# Project plotcenter to match KG_Climate_class
plotcenter_tf <- st_transform(plotcenter, crs = proj4string(r))

CC <- raster::extract(r, plotcenter_tf, df=T)

#CREATE LOOKUP TABLE TO DEFINE CLIMATE CLASSIFICATIONS EXTRACTED
# Legend must correspond to all climate classes, insert placeholders
r0 <- r[1:32]; r[1:32] <- seq(1,32,1)
# Converts raster field to categorical data
r <- ratify(r); rat <- levels(r)[[1]]
# Legend is always drawn in alphabetic order
rat$climate <- c('Af', 'Am', 'As', 'Aw', 'BSh', 'BSk', 'BWh', 'BWk', 'Cfa', 'Cfb','Cfc', 'Csa', 'Csb', 'Csc', 'Cwa','Cwb', 'Cwc', 'Dfa', 'Dfb', 'Dfc','Dfd', 'Dsa', 'Dsb', 'Dsc', 'Dsd','Dwa', 'Dwb', 'Dwc', 'Dwd', 'EF','ET', 'Ocean')
# Remove the placeholders
r[1:32] <- r0; levels(r) <- rat

#amend df to have lettered climate classifications
new <- CC
new$climate <- rat$climate[match(unlist(CC$layer), rat$ID)]

plotcenter_tf$IDs <- row.names(plotcenter_tf)
CCdata <- merge(new,plotcenter_tf, by.x="ID", by.y="IDs")

ccdata <- CCdata[,c(5,3)]

#read in reflectance/descriptive data for SRER plots
setwd("Z:/SRER/Martha/NEONpaper")
ref <- read.csv("SRERref_foliarN.csv")
#rename ID to plotID
colnames(ref)[colnames(ref)== "ID"] <- "siteID" 
#select just descriptive varibles
descvars <- ref[,c(2:7)]

#merge plot poly with descriptive variables
climateplots <- merge(descvars, ccdata, by="siteID")


write.csv(climateplots, "Climate_class_SRER.csv")
