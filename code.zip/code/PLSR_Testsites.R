library(ggplot2)
library(ggpattern)
library(extrafont)
#loadfonts(device = "win")

########################################################################################################################
############################################APPLY SINGLE BAND PLSR RESULTS##############################################
########################################################################################################################
#load data for the testing sites
test <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/testsites.csv")

#rename columns from band# to wavelength
ref <- test[,23:448]
#create wavelengths for bands
lambda <- seq(385,2510, by=5)
lambda <- sub("$", "nm", lambda) 
colnames(ref) <- lambda

#BRIGHTNESS NORM per FEILHAUER ET AL 2010
ref <- as.matrix(ref)
#brightness normalization function.
bnorm <- function(x){
  x <- x / sqrt(rowSums(x ^ 2))
}
#apply the brightness norm function
ref <- as.data.frame(bnorm(ref))

#trim data to remove begining/end portions and water absorption bands
x1 <- select(ref, `410nm`:`1330nm`)
x2 <- select(ref, `1460nm`:`1790nm`)
x3 <- select(ref, `2005nm`:`2440nm`)
x <- cbind.data.frame(x1, x2, x3)

final <- test[,c(1,19,9,5)]
########################################################################
#Apply single-band PLSR coefficients
########################################################################
#load the averaged coeff values from robust models with no spatial auto correlation
coeff <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRcoeff_allsites_BN.csv")
coeff <- coeff[,-1]
results <-  read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRresults_allsites_BN.csv")
# create df of results where [R2 validation > avg R2] and [RMSE validation < avg RMSE] (per Chadwick & Asner 2016 RSE)
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))
mean(goodmodel$testr2)
mean(goodmodel$testRMSE)

#subset the regression coeffieicnts and SR values for only the "good runs"
goodruns <- as.numeric(rownames(goodmodel))
goodcoeff <- coeff[,c(goodruns)]

#this should have 341 rows with the 1st one being the y-intercept  
coef <- as.matrix(rowMeans(goodcoeff))

#get the averaged y-intercept value
intcpt <- coef[1,]
str(intcpt)

#subset coefficient values
coefref <- as.data.frame(coef[-1,])
coefref$lambda <- names(x)
names(coefref)[names(coefref)== "coef[-1, ]"] <- "reflectance"

########################Apply PLSR coefficients to reflectance values to predict foliar N#############
mult <-  matrix(NA, nrow=nrow(x), ncol=ncol(x))

pb <- txtProgressBar(min = 2, max = 340, style = 3)
#multiply each wavelength by the coefficient value
for (i in 1:340){
  coeff <- coefref[i,1]
  mult[,i] <- x[,i] * coeff
  setTxtProgressBar(pb, i)
}


#calcualte rowsums for all multiplied values
x$sum <- apply(mult, 1, sum)
#predict Foliar N based on coefficients
final$PLSR_Npred <- x$sum + intcpt


write.csv(final, "C:/Users/farellam/Documents/FoliarN_NEON/Results/PLSR_singleband_predN.csv")



###########EVALAUTE PERFORMENCE###########
##compare measured foliar N to predicted values#
# Build the model
model <- lm(nitrogenPercent ~ PLSR_Npred, data = final)
# Summarize the model
summary(model)

#make biome column
final$biome <- rep("Temperate", nrow=nrow(final))
final$biome[final$siteID == "BONA"] <- "Continental"
final$biome[final$siteID == "NIWO"] <- "Polar"
#final$biome <- as.factor(final$biome)

#subset by biome
cont <- subset(final, biome=="Continental")
temp <- subset(final, biome=="Temperate")
polar <- subset(final, biome=="Polar")


#define equation to pur regression results on graph
#define equation to calculate linear equation
lm_eqn = function(m) {
  l <- list(a = as.numeric(format(coef(m)[1], digits = 2)),
            b = as.numeric(format(abs(coef(m)[2]), digits = 2)),
            r2 = as.numeric(format(summary(m)$r.squared, digits = 2)));
  if (l$b >= 0)  {
    eq <- substitute(italic(y) == a + b %.% italic(x)*";"~~italic(r)^2~"="~r2,l)
  } else {
    eq <- substitute(italic(y) == a - b %.% italic(x)*";"~~italic(r)^2~"="~r2,l)    
  }
  as.character(as.expression(eq));                 
}




plot1 <- ggplot(final, aes(x=PLSR_Npred, y=nitrogenPercent, col=biome))+
  xlim(0,3) + ylim(0,3)+
  geom_point()+
  geom_smooth(method=lm, se=FALSE)+
  scale_color_manual(values=c('#326186', '#AAABBC', '#37BE81'))+
  labs(x="Predicted Foliar N from single-band PLSR", y = "Measured Foliar N")+
  theme(legend.position = c(0.2, .87),
        legend.key = element_rect(fill = "transparent", colour = "transparent"))+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +
  theme(text=element_text(size=12, family="Calibri Light"))+
  guides(color=guide_legend(override.aes=list(fill=NA)))+
  annotate("text", x=2.25, y=0.5, color= "#326186", 
           label=lm_eqn(lm(PLSR_Npred ~ nitrogenPercent, cont)), parse=TRUE, family="Calibri Light")+
  annotate("text", x=2.25, y=0.3, color= "#AAABBC", 
           label=lm_eqn(lm(PLSR_Npred ~ nitrogenPercent, polar)), parse=TRUE, family="Calibri Light")+
  annotate("text", x=2.25, y=0.1, color= "#37BE81",
           label=lm_eqn(lm(PLSR_Npred ~ nitrogenPercent, temp)), parse=TRUE, family="Calibri Light")

plot1
ggsave("C:/Users/farellam/Documents/FoliarN_NEON/Results/singleband_PLSR_testing_BN.png", device='png', width=4, height=4, plot=plot1, dpi = 300, units="in")



########################################################################################################################
############################################APPLY 2-BAND BAND PLSR RESULTS##############################################
########################################################################################################################
#load the testing site reflectance data and calculate 2-band NDVI values
test <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/testsites.csv")

ref <- test[,c(23:448)]

#create wavelengths for bands
lambda <- seq(385,2510, by=5)
lambda <- sub("$", "nm", lambda) 
colnames(ref) <- lambda
#shortest, longest, and water absorption bands as NA
ref[,1:5] <- NA
ref[,191:215] <- NA
ref[,283:324] <- NA
ref[,413:426] <- NA

#NDVI, RVI, and SAVI calculation. change formula at line 34
# --------------FNI output-----------------------
pb <- txtProgressBar(min = 2, max = 426, style = 3)
k=0
for (i in 1:426){
  band1 <- ref[,i]
  for (j in 1:426){
    band2 <- ref[,j]
    FNI <- (band1-band2)/(band1+band2)#for NDVI
    #FNI <- (band1)/(band2) #for RVI
    #FNI <- (1.5*(band1-band2))/(0.5+band1+band2) #for SAVI
    if(!is.na(FNI[1])){
      k <- k+1
      ref[,426+k] <- FNI
      band1name <- colnames(ref)[i]
      band2name <- colnames(ref)[j]
      colnames(ref)[426+k] <- paste(band1name, band2name, sep="-")
    }
    
    setTxtProgressBar(pb, i)
  }}


str(ref)

# remove all columns where all readings == 0 (ie- the columns where the same band is used for band1 and band2)
FNI <- ref[,427:116026]
FNI <- FNI[, colSums(FNI !=0, na.rm=TRUE) > 0] #this works for NDVI and SAVI calculation
  #for the RVI calculation do this instead:
  #FNI <- FNI[vapply(FNI, function(x) length(unique(x[!is.na(x)]))>1, logical(1L))]

final <- test[,c(1,19,9,5)]
########################################################################
#Apply 2-band PLSR coefficients
########################################################################
#load the averaged coeff values from robust models with no spatial auto correlation
goodcoeff <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI/all_NDVI_PLSRcoef.csv")
goodcoeff <- goodcoeff[,-1]
#this should ahve 115601 rows with the 1st one being the y-intercept  
coef <- as.matrix(rowMeans(goodcoeff))
  
#get the averaged y-intercept value
intcpt <- coef[1,]
str(intcpt)

#get all wavelengths (including ones that are excluded from PLSR model)
band_combo <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/bandcombos.csv")
twoband <- paste(band_combo$band1, band_combo$band2)

#subset coefficient values
coefref <- as.data.frame(coef[-1,])
coefref$lambda <- twoband
names(coefref)[names(coefref)== "coef[-1, ]"] <- "reflectance"

########################Apply PLSR coefficients to reflectance values to predict foliar N#############
mult <-  matrix(NA, nrow=nrow(FNI), ncol=ncol(FNI))

pb <- txtProgressBar(min = 2, max = 115260, style = 3)
#multiply each wavelength by the coefficient value
for (i in 1:115260){
  coeff <- coefref[i,1]
  mult[,i] <- FNI[,i] * coeff
  setTxtProgressBar(pb, i)
}


#calcualte rowsums for all multiplied values
FNI$sum <- apply(mult, 1, sum)
final$NDVI_Npred <- FNI$sum + intcpt


write.csv(final, "C:/Users/farellam/Documents/FoliarN_NEON/Results/PLSR_NDVIpredN.csv")

##compare measured foliar N to predicted values#
# Build the model
model <- lm(nitrogenPercent ~ NDVI_Npred, data = final)
# Summarize the model
summary(model)

#make biome column
final$biome <- rep("Temperate", nrow=nrow(final))
final$biome[final$siteID == "BONA"] <- "Continental"
final$biome[final$siteID == "NIWO"] <- "Polar"
#final$biome <- as.factor(final$biome)

#subset by biome
cont <- subset(final, biome=="Continental")
temp <- subset(final, biome=="Temperate")
polar <- subset(final, biome=="Polar")


#define equation to pur regression results on graph
#define equation to calculate linear equation
lm_eqn = function(m) {
  l <- list(a = as.numeric(format(coef(m)[1], digits = 2)),
            b = as.numeric(format(abs(coef(m)[2]), digits = 2)),
            r2 = as.numeric(format(summary(m)$r.squared, digits = 2)));
  if (l$b >= 0)  {
    eq <- substitute(italic(y) == a + b %.% italic(x)*";"~~italic(r)^2~"="~r2,l)
  } else {
    eq <- substitute(italic(y) == a - b %.% italic(x)*";"~~italic(r)^2~"="~r2,l)    
  }
  as.character(as.expression(eq));                 
}




plot1 <- ggplot(final, aes(x=NDVI_Npred, y=nitrogenPercent, col=biome))+
  xlim(0,3) + ylim(0,3)+
  geom_point()+
  geom_smooth(method=lm, se=FALSE)+
  scale_color_manual(values=c('#326186', '#AAABBC', '#37BE81'))+
  labs(x="Predicted Foliar N from 2-band (NDVI) PLSR", y = "Measured Foliar N")+
  theme(legend.position = c(2, .87), legend.key = element_rect(fill = "transparent", colour = "transparent"))+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +
  theme(text=element_text(size=12, family="Calibri Light"))+
  guides(color=guide_legend(override.aes=list(fill=NA)))+
  annotate("text", x=2.25, y=0.5, color= "#326186", 
           label=lm_eqn(lm(NDVI_Npred ~ nitrogenPercent, cont)), parse=TRUE, family="Calibri Light")+
  annotate("text", x=2.25, y=0.3, color= "#AAABBC", 
           label=lm_eqn(lm(NDVI_Npred ~ nitrogenPercent, polar)), parse=TRUE, family="Calibri Light")+
  annotate("text", x=2.25, y=0.1, color= "#37BE81",
           label=lm_eqn(lm(NDVI_Npred ~ nitrogenPercent, temp)), parse=TRUE, family="Calibri Light")

plot1
ggsave("C:/Users/farellam/Documents/FoliarN_NEON/Results/NDVI_PLSR_testing.png", device='png', width=4, height=4, plot=plot1, dpi = 300, units="in")
