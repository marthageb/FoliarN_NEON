library(dplyr)
library(ggplot2)
require(gridExtra)

#jpeg("C:/Users/Kangaroo/Documents/Dissertation/ms1/Fig2.jpeg", width = 2250, height = 2700, res = 300)
#tiff("C:/Users/Kangaroo/Documents/Dissertation/ms1/Fig2.tiff", height=2700, width=2250, compression = "lzw", res=300 )

##GET WAVELENGTH BANDS
#load ref data for all plant clip locations
data <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/oldanalysis.csv")
str(data[,c(1:13)])
#rename columns from band# to wavelength
ref <- data[,28:453]
#create wavelengths for bands
lambda <- seq(385,2510, by=5)
lambda <- sub("$", "nm", lambda) 
colnames(ref) <- lambda

#trim data to remove begining/end portions and water absorption bands
x1 <- select(ref, `410nm`:`1330nm`)
x2 <- select(ref, `1460nm`:`1790nm`)
x3 <- select(ref, `2005nm`:`2440nm`)
x <- cbind(x1, x2, x3)


##ALL SITES
#output from 'PLSRloop.R'
results <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRresults_allsites_BN.csv")
VIP.frame <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRvip_allsites_BN.csv", stringsAsFactors = F)
VIP.frame <- VIP.frame[,-1]

results <- results[complete.cases(results), ]

mean(results$trainr2)
mean(results$trainRMSE)
mean(results$testr2)
mean(results$testRMSE)
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))
#subset the regression coeffieicnts and SR values for only the "good runs"
goodruns <- as.numeric((goodmodel$X))
goodVIP <- VIP.frame[,c(goodruns)]

allVIP <- rowMeans(goodVIP)

#combine the avg coeff and VIP scores into a single df with wavelength bands
#get the wavelength bands
rn <- as.character(colnames(x))#"x" is from PLSRloop.R line 22 or 152
avgdf <- cbind.data.frame(rn, allVIP)
str(avgdf)

#add the wavelength regions that were excluded
#create vector of excluded bands
lambda1 <- seq(385,405, by=5)
lambda2 <- seq(1335,1455, by=5)
lambda3 <- seq(1795,2000, by=5)
lambda4 <- seq(2445, 2510, by=5)
lambda <- c(lambda1, lambda2, lambda3, lambda4)
lambda <- sub("$", "nm", lambda) 
#add "NA" columns
colNAs <-matrix(NaN, nrow=length(lambda), ncol=1)
colNAs <- cbind.data.frame(lambda,colNAs)
colnames(colNAs) <- c("rn", "allVIP")

allvals <- rbind.data.frame(avgdf,colNAs)
#reorder data in wavelength order
lamnum <- allvals[,1]
lamnum <- sub("nm", "", lamnum)
lamnum <- as.numeric(lamnum)
#assign the numeric wavelength as column and row names
rownames(allvals) <- lamnum
#order the df in decending wavelength order
order <- allvals[ order(as.numeric(row.names(allvals))), ]
order$band <- as.numeric(row.names(order))


####GET TEMPERATE SITE VIPS####
results <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRresults_temperate_BN.csv")
VIP.frame <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRvip_temperate_BN.csv", stringsAsFactors = F)
VIP.frame <- VIP.frame[,-1]

results <- results[complete.cases(results), ]
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))
#subset the regression coeffieicnts and SR values for only the "good runs"
goodruns <- as.numeric((goodmodel$X))
goodVIP <- VIP.frame[,c(goodruns)]

tempVIP <- rowMeans(goodVIP)
avgdf <- cbind.data.frame(rn, tempVIP)

colnames(colNAs) <- c("rn", "tempVIP")
allvals <- rbind.data.frame(avgdf,colNAs)
#reorder data in wavelength order
lamnum <- allvals[,1]
lamnum <- sub("nm", "", lamnum)
lamnum <- as.numeric(lamnum)
#assign the numeric wavelength as column and row names
rownames(allvals) <- lamnum

order_temp <- allvals[ order(as.numeric(row.names(allvals))), ]
temp <- order_temp[,2]
order <- cbind.data.frame(order,temp)


####GET ARID SITE VIPS####
results <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRresults_arid_BN.csv")
VIP.frame <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRvip_arid_BN.csv", stringsAsFactors = F)
VIP.frame <- VIP.frame[,-1]

results <- results[complete.cases(results), ]
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))
#subset the regression coeffieicnts and SR values for only the "good runs"
goodruns <- as.numeric((goodmodel$X))
goodVIP <- VIP.frame[,c(goodruns)]

aridVIP <- rowMeans(goodVIP)
avgdf <- cbind.data.frame(rn, aridVIP)

colnames(colNAs) <- c("rn", "aridVIP")
allvals <- rbind.data.frame(avgdf,colNAs)
#reorder data in wavelength order
lamnum <- allvals[,1]
lamnum <- sub("nm", "", lamnum)
lamnum <- as.numeric(lamnum)
#assign the numeric wavelength as column and row names
rownames(allvals) <- lamnum

order_temp <- allvals[ order(as.numeric(row.names(allvals))), ]
arid <- order_temp[,2]
order <- cbind.data.frame(order,arid)

####GET CONTINENTAL SITE VIPS####
results <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRresults_continental_BN.csv")
VIP.frame <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRvip_continental_BN.csv", stringsAsFactors = F)
VIP.frame <- VIP.frame[,-1]

results <- results[complete.cases(results), ]
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))
#subset the regression coeffieicnts and SR values for only the "good runs"
goodruns <- as.numeric((goodmodel$X))
goodVIP <- VIP.frame[,c(goodruns)]

contVIP <- rowMeans(goodVIP)
avgdf <- cbind.data.frame(rn, contVIP)

colnames(colNAs) <- c("rn", "contVIP")
allvals <- rbind.data.frame(avgdf,colNAs)
#reorder data in wavelength order
lamnum <- allvals[,1]
lamnum <- sub("nm", "", lamnum)
lamnum <- as.numeric(lamnum)
#assign the numeric wavelength as column and row names
rownames(allvals) <- lamnum

order_temp <- allvals[ order(as.numeric(row.names(allvals))), ]
cont <- order_temp[,2]
order <- cbind.data.frame(order,cont)

####GET TROPICAL SITE VIPS####
results <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRresults_tropical_BN.csv")
VIP.frame <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRvip_tropical_BN.csv", stringsAsFactors = F)
VIP.frame <- VIP.frame[,-1]

results <- results[complete.cases(results), ]
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))
#subset the regression coeffieicnts and SR values for only the "good runs"
goodruns <- as.numeric((goodmodel$X))
goodVIP <- VIP.frame[,c(goodruns)]

tropVIP <- rowMeans(goodVIP)
avgdf <- cbind.data.frame(rn, tropVIP)

colnames(colNAs) <- c("rn", "tropVIP")
allvals <- rbind.data.frame(avgdf,colNAs)
#reorder data in wavelength order
lamnum <- allvals[,1]
lamnum <- sub("nm", "", lamnum)
lamnum <- as.numeric(lamnum)
#assign the numeric wavelength as column and row names
rownames(allvals) <- lamnum

order_temp <- allvals[ order(as.numeric(row.names(allvals))), ]
trop <- order_temp[,2]
order <- cbind.data.frame(order,trop)

###MAKE THE GRAPH###
windowsFonts(A=windowsFont("Calibri Light"))
#all sites col="#696969
#temperate col="#37be81"
#arid col="#fecb34"
#continental col="#326186"
#tropical col="#d14d28"


########PLOTTING###############
#To export as 300dpi
tiff("C:/Users/farellam/Documents/FoliarN_NEON/Results/Fig4.tiff",  width = 3605, height = 2060, res = 300)

par(mfrow=c(2,3), mai=c(0.2,0.2,0,0), oma=c(3,3.2,0.1,0.4))  #2 rows 3 column, mai sets margins of the plot in inches, oma sets outer figure margins

###ALL SITES
plot(order$band, order$allVIP, type="l", col="#696969", lwd=2, ylim=c(0,3.2), xaxt="n", yaxt="n", xlab="", ylab="")
axis(2, at=c(0,1,2,3), labels=c("0", "1", "2", "3"), cex.axis=2.1, family="A")
mtext("PLSR VIP Score", side=2, line=2.7, adj=0.5, cex=1.8, family="A")
axis(1, at=c(500,1000,1500, 2000, 2500), labels=c("500", "1000", "1500", "2000", "2500"), cex.axis=2.1, family="A")
mtext("Wavelength (nm)", side=1, line=2.95, adj=0.5, cex=1.8, family="A")
#mtext("a. All Sites", side=3, line=0, adj=0, cex=1.5, family="A")
text(700,3.1, labels="a. All Sites", family="A", cex=2.7)

###TEMPERATE SITES
plot(order$band, order$temp, type="l", col="#37BE81", lwd=2, ylim=c(0,3.2), xaxt="n", yaxt="n", xlab="", ylab="")
axis(2, at=c(0,1,2,3), labels=c("", "", "", ""), cex.axis=1.8, family="A")
axis(1, at=c(500,1000,1500, 2000, 2500), labels=c("", "", "", "", ""), cex.axis=1.5, family="A")
#mtext("b. Temperate Sites", side=3, line=0, adj=0, cex=1.5, family="A")
text(1300,3.1, labels="b. Temperate Biome Sites", family="A", cex=2.7)

###ARID SITES
plot(order$band, order$arid, type="l", col="#fecb34", lwd=2, ylim=c(0,3.2), xaxt="n", yaxt="n", xlab="", ylab="")
axis(2, at=c(0,1,2,3), labels=c("", "", "", ""), cex.axis=1.8, family="A")
axis(1, at=c(500,1000,1500, 2000, 2500), labels=c("", "", "", "", ""), cex.axis=1.5, family="A")
#mtext("c. Arid Sites", side=3, line=0, adj=0, cex=1.5, family="A")
text(1025,3.1, labels="c. Arid Biome Sites", family="A", cex=2.7)

###BLANK PLOT
plot(1, type="n", axes=F, xlab="", ylab="")

###CONTINENTAL SITES
plot(order$band, order$cont, type="l", col="#326186", lwd=2, ylim=c(0,3.2), xaxt="n", yaxt="n", xlab="", ylab="")
axis(2, at=c(0,1,2,3), labels=c("0", "1", "2", "3"), cex.axis=2.1, family="A")
mtext("PLSR VIP Score", side=2, line=2.7, adj=0.5, cex=1.8, family="A")
axis(1, at=c(500,1000,1500, 2000, 2500), labels=c("500", "1000", "1500", "2000", "2500"), cex.axis=2.1, family="A")
mtext("Wavelength (nm)", side=1, line=2.95, adj=0.5, cex=1.8, family="A")
#mtext("d. Continental Biome", side=3, line=0, adj=0, cex=1.5, family="A")
text(1320,3.1, labels="d. Continental Biome Sites", family="A", cex=2.7)

###TROPICAL SITES
plot(order$band, order$trop, type="l", col="#d14d28", lwd=2, ylim=c(0,3.2), xaxt="n", yaxt="n", xlab="", ylab="")
axis(2, at=c(0,1,2,3), labels=c("", "", "", ""), cex.axis=1.8, family="A")
axis(1, at=c(500,1000,1500, 2000, 2500), labels=c("500", "1000", "1500", "2000", "2500"), cex.axis=2.1, family="A")
mtext("Wavelength (nm)", side=1, line=2.95, adj=0.5, cex=1.8, family="A")
#mtext("e. Tropical Biome", side=3, line=0, adj=0, cex=1.5, family="A")
text(1200,3.1, labels="e. Tropical Biome Sites", family="A", cex=2.7)

#exported 1225 x 700

dev.off()
