library(pls)
library(plsVarSel)
library(dplyr)

setwd("C:/Users/farellam/Documents/FoliarN_NEON/data/")


#load ref data for all plant clip locations
data <- read.csv("oldanalysis.csv")
str(data[,c(1:13)])
#rename columns from band# to wavelength
ref <- data[,28:453]
#create wavelengths for bands
lambda <- seq(385,2510, by=5)
lambda <- sub("$", "nm", lambda) 
colnames(ref) <- lambda

#BRIGHTNESS NORM per FEILHAUER ET AL 2010
ref <- as.matrix(ref)
#brightness normalization function.
bnorm <- function(x){
  x <- x / sqrt(rowSums(x ^ 2))
}
#apply the brightness norm function
ref <- as.data.frame(bnorm(ref))


#trim data to remove begining/end portions and water absorption bands
x1 <- select(ref, `410nm`:`1330nm`)
x2 <- select(ref, `1460nm`:`1790nm`)
x3 <- select(ref, `2005nm`:`2440nm`)
x <- cbind(x1, x2, x3)

#if wanting to exclude cases where FNI val = NA ***need to do this for SR calculation****
reffoliarN <- cbind(data$ntrgnPr, x)
nona <- reffoliarN[complete.cases(reffoliarN[,2:341]),] #***remove any cases with FNI = NA **need to exclude these rows from PLSR for SR calculation
FNInona <- nona[,2:341]
##convert selected wavelengths into SPC (format needed for PLSR)
foliar <- data.frame(nona[,1], SPC=I(as.matrix(FNInona)))
#rename foliar N var
colnames(foliar)[colnames(foliar)=="nona...1."] <- "foliarN"


###########PLSR LOOP#########
#SET SEED TO INITIALLY CONTROL "RANDOMNESS"
set.seed(6)
#NUMBER OF ITERATIONS
n.loop<-100

#create matrices for storage

#unsure if length of TestIDs will always be the same
min.err.frame<-matrix(NA, nrow=n.loop, ncol=1)
min.comp.frame<-matrix(NA, nrow=n.loop, ncol=1)
var.frame<-matrix(NA, nrow=n.loop, ncol=1)
pred.err.frame<-matrix(NA, nrow=n.loop, ncol=1)
pred.var.frame<-matrix(NA, nrow=n.loop, ncol=1)
coeff.frame <- matrix(NA, nrow=length(x)+1, ncol=n.loop)
VIP.frame <- matrix(NA, nrow=length(x), ncol=n.loop)
SR.frame <- matrix(NA, nrow=length(x), ncol=n.loop)

#start loop
pb <- txtProgressBar(min = 1, max = 100, style = 3)

for(i in 1:n.loop){
  
  #create a training and testing dataset
  #Shuffle Rowwise: 
  foliar_rand <- foliar[sample(nrow(foliar)),]
  #Divide data set into training and test set (80% training and 20% testing)
  # To generate integers WITHOUT replacement:
  trainN <- round(nrow(foliar) * 0.8)
  random <- sample(1:nrow(foliar), trainN, replace=FALSE)
  
  datTrain <- foliar_rand[c(random),]
  datTest <- foliar_rand[-c(random),]
  #str(datTrain)
  #str(datTest)
  
  #define the model parameters and run the plsr model
  #(response_var ~ predictor_var, data)
  plsFit <- plsr(foliarN ~ SPC, data = datTrain, ncomp = 20,validation="CV", segment.type = "interleaved", segments= 10)
  # summary(plsFit)
  #calculate the minimum RMSEP
  error <-  RMSEP(plsFit, estimate="adjCV")
  min_err <- min(error$val)
  #min_err
  min.err.frame[i,]<-min_err
  
  #determine the # of comps that corresponds with the minimum RMSEP
  #need to subtract 1 bacause indexing starts at intercept (not the 1st comp)
  min_comp <- which.min(error$val)-1
  #min_comp
  min.comp.frame[i,]<-min_comp
  
  #calculate the R2 for # of components defined above
  var <- R2(plsFit, estimate="train", comps=1:min_comp)
  var
  #r2 for model
  var.frame[i,] <- var$val
  #get the VIP and selectivity ratio values for the minimum # of components defined
  VIP.frame[,i] <- VIP(plsFit, min_comp)
  X <- unclass(datTrain$SPC)
  SR.frame[,i] <- SR(plsFit, min_comp,X)
  
  #use the plsr model and the optimal # of comps IDed to predict plot N values that were left out of model development
  plsPred <- predict(plsFit, datTest, ncomp=min_comp)
  # evaluate how well the model performed
  pls.eval=data.frame(obs=datTest$foliarN, pred=plsPred[,1,1])
  ##needs caret package... will give you RMSE and R2 for the test data
  #DOUBLE COLON!
  info <- caret::defaultSummary(pls.eval)
  pred_err <- as.numeric(info[1:1])
  pred_var <- as.numeric(info[2:2])
  pred.err.frame[i,] <- pred_err
  pred.var.frame[i,] <- pred_var
  
  coeff.frame[,i] <- coef(plsFit,  ncomp=min_comp, intercept = TRUE)
  setTxtProgressBar(pb, i)
  
}

#can convert to data.frame
min.err.frame <- data.frame(min.err.frame)
min.comp.frame <- data.frame(min.comp.frame)
var.frame <- data.frame(var.frame)
pred.err.frame <- data.frame(pred.err.frame)
pred.var.frame <- data.frame(pred.var.frame)
coeff.frame <- data.frame(coeff.frame)
VIP.frame <- data.frame(VIP.frame)
SR.frame <- data.frame(SR.frame)

results <- cbind(min.err.frame, min.comp.frame, var.frame, pred.err.frame, pred.var.frame)
colnames(results) <- c("trainRMSE", "ncomp", "trainr2", "testRMSE", "testr2")

mean(results$trainr2)
mean(results$trainRMSE)
mean(results$testr2)
mean(results$testRMSE)

write.csv(results, "C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRresults_allsites_BN.csv")
write.csv(coeff.frame, "C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRcoeff_allsites_BN.csv")
write.csv(VIP.frame, "C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRvip_allsites_BN.csv")
write.csv(SR.frame, "C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRsr_allsites_BN.csv")

# create df of results where [R2 validation > avg R2] and [RMSE validation < avg RMSE] (per Chadwick & Asner 2016 RSE)
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))
mean(goodmodel$testr2)
mean(goodmodel$testRMSE)


###########################################################################
#########################subset by biome###################################
###########################################################################
biome <- subset(data, biome== "Tropical")


#rename columns from band# to wavelength
ref <- biome[,28:453]
#create wavelengths for bands
lambda <- seq(385,2510, by=5)
lambda <- sub("$", "nm", lambda) 
colnames(ref) <- lambda

#BRIGHTNESS NORM per FEILHAUER ET AL 2010
ref <- as.matrix(ref)
#brightness normalization function.
bnorm <- function(x){
  x <- x / sqrt(rowSums(x ^ 2))
}
#apply the brightness norm function
ref <- as.data.frame(bnorm(ref))

#trim data to remove begining/end portions and water absorption bands
x1 <- select(ref, `410nm`:`1330nm`)
x2 <- select(ref, `1460nm`:`1790nm`)
x3 <- select(ref, `2005nm`:`2440nm`)
x <- cbind(x1, x2, x3)

#if wanting to exclude cases where FNI val = NA ***need to do this for SR calculation****
reffoliarN <- cbind(biome$ntrgnPr, x)
nona <- reffoliarN[complete.cases(reffoliarN[,2:341]),] #***remove any cases with FNI = NA **need to exclude these rows from PLSR for SR calculation
FNInona <- nona[,2:341]
##convert selected wavelengths into SPC (format needed for PLSR)
foliar <- data.frame(nona[,1], SPC=I(as.matrix(FNInona)))
#rename foliar N var
colnames(foliar)[colnames(foliar)=="nona...1."] <- "foliarN"

#SET SEED TO INITIALLY CONTROL "RANDOMNESS"
set.seed(6)
#NUMBER OF ITERATIONS
n.loop<-100

#create matrices for storage

#unsure if length of TestIDs will always be the same
min.err.frame<-matrix(NA, nrow=n.loop, ncol=1)
min.comp.frame<-matrix(NA, nrow=n.loop, ncol=1)
var.frame<-matrix(NA, nrow=n.loop, ncol=1)
pred.err.frame<-matrix(NA, nrow=n.loop, ncol=1)
pred.var.frame<-matrix(NA, nrow=n.loop, ncol=1)
coeff.frame <- matrix(NA, nrow=length(x)+1, ncol=n.loop)
VIP.frame <- matrix(NA, nrow=length(x), ncol=n.loop)
SR.frame <- matrix(NA, nrow=length(x), ncol=n.loop)
#start loop
for(i in 1:n.loop){
  
  #create a training and testing dataset
  #Shuffle Rowwise: 
  foliar_rand <- foliar[sample(nrow(foliar)),]
  #Divide data set into training and test set (80% training and 20% testing)
  #Divide data set into training and test set (80% training and 20% testing)
  # To generate integers WITHOUT replacement:
  trainN <- round(nrow(foliar) * 0.8)
  random <- sample(1:nrow(foliar), trainN, replace=FALSE)
  
  datTrain <- foliar_rand[c(random),]
  datTest <- foliar_rand[-c(random),]
  #str(datTrain)
  #str(datTest)
  
  #define the model parameters and run the plsr model
  #(response_var ~ predictor_var, data)
  plsFit <- plsr(foliarN ~ SPC, data = datTrain, ncomp = 20,validation="CV", segment.type = "interleaved", segments= 10)
  # summary(plsFit)
  #calculate the minimum RMSEP
  error <-  RMSEP(plsFit, estimate="adjCV")
  min_err <- min(error$val)
  #min_err
  min.err.frame[i,]<-min_err
  
  #determine the # of comps that corresponds with the minimum RMSEP
  #need to subtract 1 bacause indexing starts at intercept (not the 1st comp)
  min_comp <- which.min(error$val)-1
  #min_comp
  min.comp.frame[i,]<-min_comp
  
  if (min_comp > 0){
  #calculate the R2 for # of components defined above
  var <- pls::R2(plsFit, estimate="train", comps=1:min_comp)
  var
  #r2 for model
  var.frame[i,] <- var$val
  #get the VIP and selectivity ratio values for the minimum # of components defined
  VIP.frame[,i] <- VIP(plsFit, min_comp)
  X <- unclass(datTrain$SPC)
  SR.frame[,i] <- SR(plsFit, min_comp,X)

  #use the plsr model and the optimal # of comps IDed to predict plot N values that were left out of model development
  plsPred <- predict(plsFit, datTest, ncomp=min_comp)
  # evaluate how well the model performed
  pls.eval=data.frame(obs=datTest$foliarN, pred=plsPred[,1,1])
  ##needs caret package... will give you RMSE and R2 for the test data
  #DOUBLE COLON!
  info <- caret::defaultSummary(pls.eval)
  pred_err <- as.numeric(info[1:1])
  pred_var <- as.numeric(info[2:2])
  pred.err.frame[i,] <- pred_err
  pred.var.frame[i,] <- pred_var
  
  coeff.frame[,i] <- coef(plsFit,  ncomp=min_comp, intercept = TRUE)
  } else {
    var.frame[i,] <- "NA"
    pred.err.frame[i,] <- "NA"
    pred.var.frame[i,] <- "NA"
    coeff.frame[,i] <- "NA"
    VIP.frame[,i] <- "NA"
    SR.frame[,i] <- "NA"
  }
}


#can convert to data.frame
min.err.frame <- data.frame(min.err.frame)
min.comp.frame <- data.frame(min.comp.frame)
var.frame <- data.frame(as.numeric(var.frame))
pred.err.frame <- data.frame(as.numeric(pred.err.frame))
pred.var.frame <- data.frame(as.numeric(pred.var.frame))
coeff.frame <- data.frame(coeff.frame)
VIP.frame <- data.frame(VIP.frame)
SR.frame <- data.frame(SR.frame)

results <- cbind(min.err.frame, min.comp.frame, var.frame, pred.err.frame, pred.var.frame)
colnames(results) <- c("trainRMSE", "ncomp", "trainr2", "testRMSE", "testr2")

results <- results[complete.cases(results), ]

mean(results$trainr2)
mean(results$trainRMSE)
mean(results$testr2)
mean(results$testRMSE)

write.csv(results, "C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRresults_tropical_BN.csv")
write.csv(coeff.frame, "C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRscoeff_tropical_BN.csv")
write.csv(VIP.frame, "C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRvip_tropical_BN.csv")
write.csv(SR.frame, "C:/Users/farellam/Documents/FoliarN_NEON/Results/single_band/PLSRsr_tropical_BN.csv")

# create df of results where [R2 validation > avg R2] and [RMSE validation < avg RMSE] (per Chadwick & Asner 2016 RSE)
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))
mean(goodmodel$testr2)
mean(goodmodel$testRMSE)

###########################################################################
#######################FNI 2 band combinations#############################
###########################################################################
#########FNI 2 band combinations#########
#FNI <- read.csv("FNIall.csv")  #usually won't load because file size is too large, and need to re-run beginning portion of 'FNIcalc_Fig3.R" to create dataframe instead
#data <- read.csv("foliarNref_wSRER.csv")
#After getting the FNI calcualted values:
FNI <- regdata1[,-c(1:2)]
foliar <- data.frame(regdata1[,1], SPC=I(as.matrix(FNI)))
colnames(foliar)[colnames(foliar)=="regdata1...1."] <- "foliarN"

#if wanting to exclude cases where FNI val = NA ***need to do this for SR calculation****
  FNIfoliarN <- cbind(regdata1[,1], FNI)
  nona <- FNIfoliarN[complete.cases(FNIfoliarN[,2:115261]),] #***remove any cases with FNI = NA **need to exclude these rows from PLSR for SR calculation
  nona <- nona[!is.infinite(rowSums(nona[,2:115261])),] #remove any cases with FNI= Inf
  
  FNInona <- nona[,2:115261]
  foliar <- data.frame(nona[,1], SPC=I(as.matrix(FNInona)))
  colnames(foliar)[colnames(foliar)=="nona...1."] <- "foliarN"
  
####if wanting to subset x biome:
  biome <- cbind(data[,c(5,18)],FNI)
  temperate <- subset(biome, biome=="Temperate") 
  arid <- subset(biome, biome=="Arid")
  continental <- subset(biome, biome=="Continental")
  tropical <- subset(biome, biome=="Tropical")
  

  #***remove cases with FNI = NA **need to exclude these rows from PLSR for SR calculation
  nona <- tropical[complete.cases(tropical[,3:115262]),] 
  biomeFNI <- nona[,c(3:115262)]
  foliar <- data.frame(nona[,1], SPC=I(as.matrix(biomeFNI)))
  colnames(foliar)[colnames(foliar)=="nona...1."] <- "foliarN"
  

#SET SEED TO INITIALLY CONTROL "RANDOMNESS"
set.seed(6)
#NUMBER OF ITERATIONS
n.loop<-100

#create matrices for storage

#unsure if length of TestIDs will always be the same
min.err.frame<-matrix(NA, nrow=n.loop, ncol=1)
min.comp.frame<-matrix(NA, nrow=n.loop, ncol=1)
var.frame<-matrix(NA, nrow=n.loop, ncol=1)
pred.err.frame<-matrix(NA, nrow=n.loop, ncol=1)
pred.var.frame<-matrix(NA, nrow=n.loop, ncol=1)
coeff.frame <- matrix(NA, nrow=length(FNI)+1, ncol=n.loop)
VIP.frame <- matrix(NA, nrow=length(FNI), ncol=n.loop)
SR.frame <- matrix(NA, nrow=length(FNI), ncol=n.loop)


pb <- txtProgressBar(min = 1, max = n.loop, style = 3)

#start loop
for(i in 1:n.loop){
  
  #create a training and testing dataset
  #Shuffle Rowwise: 
  foliar_rand <- foliar[sample(nrow(foliar)),]
  #Divide data set into training and test set (80% training and 20% testing)
  # To generate integers WITHOUT replacement:
  trainN <- round(nrow(foliar) * 0.8)
  random <- sample(1:nrow(foliar), trainN, replace=FALSE)
  
  datTrain <- foliar_rand[c(random),]
  datTest <- foliar_rand[-c(random),]
  
  #str(datTrain)
  #str(datTest)
  
  #define the model parameters and run the plsr model
  #(response_var ~ predictor_var, data)
  plsFit <- plsr(foliarN ~ SPC, data = datTrain, ncomp = 20,validation="CV", segment.type = "interleaved", segments= 10)
  # summary(plsFit)
  #calculate the minimum RMSEP
  error <-  RMSEP(plsFit, estimate="adjCV")
  min_err <- min(error$val)
  #min_err
  min.err.frame[i,]<-min_err
  
  #determine the # of comps that corresponds with the minimum RMSEP
  #need to subtract 1 bacause indexing starts at intercept (not the 1st comp)
  min_comp <- which.min(error$val)-1
  #min_comp
  min.comp.frame[i,]<-min_comp
  
    if (min_comp > 0){
    #calculate the R2 for # of components defined above
    var <- R2(plsFit, estimate="train", comps=1:min_comp)
    var
    #r2 for model
    var.frame[i,] <- var$val
    #get the VIP and selectivity ratio values for the minimum # of components defined
    VIP.frame[,i] <- VIP(plsFit, min_comp)
    X <- unclass(datTrain$SPC)
    SR.frame[,i] <- SR(plsFit, min_comp,X)
    #use the plsr model and the optimal # of comps IDed to predict plot N values that were left out of model development
    plsPred <- predict(plsFit, datTest, ncomp=min_comp)
    # evaluate how well the model performed
    pls.eval=data.frame(obs=datTest$foliarN, pred=plsPred[,1,1])
    ##needs caret package... will give you RMSE and R2 for the test data
    #DOUBLE COLON!
    info <- caret::defaultSummary(pls.eval)
    pred_err <- as.numeric(info[1:1])
    pred_var <- as.numeric(info[2:2])
    pred.err.frame[i,] <- pred_err
    pred.var.frame[i,] <- pred_var
    
    coeff.frame[,i] <- coef(plsFit,  ncomp=min_comp, intercept = TRUE)
  } else {
    var.frame[i,] <- "NA"
    pred.err.frame[i,] <- "NA"
    pred.var.frame[i,] <- "NA"
    coeff.frame[,i] <- "NA"
    VIP.frame[,i] <-"NA"
    SR.frame[,i] <- "NA"
  }
  setTxtProgressBar(pb, i)
}

#all samples (n = 624) and all FNI values (n = 117,306) 100 PLSR iterations started at 10:00am 8April finished around 2:15pm = 4hr15min
  #start: 4:18

#can convert to data.frame
min.err.frame <- data.frame(min.err.frame)
min.comp.frame <- data.frame(min.comp.frame)
var.frame <- data.frame(as.numeric(var.frame))
pred.err.frame <- data.frame(as.numeric(pred.err.frame))
pred.var.frame <- data.frame(as.numeric(pred.var.frame))
coeff.frame <- data.frame(coeff.frame)
VIP.frame <- data.frame(VIP.frame)
SR.frame <- data.frame(SR.frame)

results <- cbind(min.err.frame, min.comp.frame, var.frame, pred.err.frame, pred.var.frame)
colnames(results) <- c("trainRMSE", "ncomp", "trainr2", "testRMSE", "testr2")

#rownames(coeff.frame) <- colnames(FNIarid)
#rownames(VIP.frame) <- colnames(FNIarid)
#rownames(SR.frame) <- colnames(FNIarid)


#write.csv(results, "./FNI/RVI/PLSR_results_all.csv")
#write.csv(coeff.frame, "./FNI/RVI/PLSR_coeff_all.csv")
#write.csv(VIP.frame, "./FNI/RVI/PLSR_VIP_all.csv")
#write.csv(SR.frame, "./FNI/RVI/PLSR_SR_all.csv")

###########################
#results <- read.csv("./PLSR_FNI_results/arid_r2_RMSE.csv")
#SR.frame <- read.csv("./PLSR_FNI_results/arid_SR.csv")
#VIP.frame <- read.csv("./PLSR_FNI_results/arid_VIP.csv")
#coeff.frame <- read.csv("./PLSR_FNI_results/arid_coeff.csv")

results <- results[complete.cases(results), ]

mean(results$trainr2, na.omit=TRUE)
mean(results$trainRMSE)
mean(results$testr2)
mean(results$testRMSE)
# create df of results where [R2 validation > avg R2] and [RMSE validation < avg RMSE] (per Chadwick & Asner 2016 RSE)
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))

mean(goodmodel$testr2)
mean(goodmodel$testRMSE)

#subset the regression coeffieicnts and SR values for only the "good runs"
goodruns <- as.numeric(rownames(goodmodel))
goodcoeff <- coeff.frame[,c(goodruns)]
goodSR <- SR.frame[,c(goodruns)]
goodVIP <- VIP.frame[,c(goodruns)]

write.csv(results, "C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI/all_RVI_PLSRresults.csv")
write.csv(goodcoeff, "C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI/all_RVI_PLSRcoef.csv")
write.csv(goodSR, "C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI/all_RVI_PLSR_SR.csv")
write.csv(goodVIP, "C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI/all_RVI_PLSR_VIP.csv")


FNIbandcombos <- read.csv("FNIbandcombos.csv")
rn <- as.character(FNIbandcombos$bandcombo)
twobands <- do.call(rbind, strsplit(rn, '-'))

avgSR <- rowMeans(goodSR)
avgSR

#cbind band1, band2, and avg coeff into a new df
dfvals <- cbind.data.frame(twobands,avgSR)
names(dfvals)[names(dfvals) == "1"] <- "band1"
names(dfvals)[names(dfvals) == "2"] <- "band2"
