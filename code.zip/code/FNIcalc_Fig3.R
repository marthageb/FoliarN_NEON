library(autopls)
library(gplots)
library(RColorBrewer)
library(reshape2)
library(viridis)

#setwd
setwd("C:/Users/farellam/Documents/FoliarN_NEON/data/")

#load 2 band combos
FNIbandcombos <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/bandcombos.csv")
FNIbandcombos$twoband <- paste(FNIbandcombos$band1, FNIbandcombos$band2, sep="-")
twobands <- FNIbandcombos[,c(1:2)]

#load ref data for all plant clip locations
data <- read.csv("oldanalysis.csv")
#exclude SRER samples
data <- subset(data, !siteID =="SRER")

data <- data[,-c(1:3)]
str(data[,c(1:13)])

#rename columns from band# to wavelength
ref <- data[,25:450]
#create wavelengths for bands
lambda <- seq(385,2510, by=5)
lambda <- sub("$", "nm", lambda) 
colnames(ref) <- lambda
#shortest, longest, and water absorption bands as NA
ref[,1:5] <- NA
ref[,191:215] <- NA
ref[,283:324] <- NA
ref[,413:426] <- NA

#NDVI, RVI, and SAVI calculation. change formula at line 34
# --------------FNI output-----------------------
pb <- txtProgressBar(min = 2, max = 426, style = 3)
k=0
for (i in 1:426){
  band1 <- ref[,i]
  for (j in 1:426){
    band2 <- ref[,j]
    #FNI <- (band1-band2)/(band1+band2)#for NDVI
    #FNI <- (band1)/(band2) #for RVI
    FNI <- (1.5*(band1-band2))/(0.5+band1+band2) #for SAVI
    if(!is.na(FNI[1])){
      k <- k+1
      ref[,426+k] <- FNI
      band1name <- colnames(ref)[i]
      band2name <- colnames(ref)[j]
      colnames(ref)[426+k] <- paste(band1name, band2name, sep="-")
    }
    
    setTxtProgressBar(pb, i)
  }}


str(ref)
# remove all columns where all readings == 0 (ie- the columns where the same band is used for band1 and band2)
FNI <- ref[,427:116026]
FNI <- FNI[, colSums(FNI !=0, na.rm=TRUE) > 0] #this works for NDVI and SAVI calculation
  #for the RVI calculation do this instead:
  #FNI <- FNI[vapply(FNI, function(x) length(unique(x[!is.na(x)]))>1, logical(1L))]

  
####BEST 2-BAND COMBO####
  #subset x biome
  regdata1 <- cbind(data$biome, FNI)
  names(regdata1)[1] <- "biome"
  regdata1 <- cbind(data$ntrgnPr, regdata1)
  names(regdata1)[1] <- "ntrgnPr"
  temperate <- subset(regdata1, biome== "Temperate")
  arid <- subset(regdata1, biome== "Arid")
  tropical <- subset(regdata1, biome== "Tropical")
  continental <- subset(regdata1,biome== "Continental")

  FNI <- tropical[,-c(1:2)]
  foliarN <- tropical[,1]
  

#create empty matrix to store correlations
FNI_foliarN <- matrix(NA, nrow=ncol(FNI), ncol=1)
FNI_RMSE <- matrix(NA, nrow=ncol(FNI), ncol=1)

#perform calcualte FNI for each 2 band combination and create correlation matrix of FNI:FoliarN
pb <- txtProgressBar(min = 2, max = ncol(FNI), style = 3)

for (i in 1:ncol(FNI)){
    #foliarNcor <- (cor(FNI[,i], foliarN, use="pairwise.complete.obs"))^2
    #FNI_foliarN[i,] <- foliarNcor
    FNIreg <- (FNI[,i])
    FNIreg[which(is.nan(FNIreg))] = NA
    FNIreg[which(FNIreg==Inf)] = NA
    #if (all(is.na(FNIreg)) == "TRUE") {
    #  FNI_foliarN[i,] <- NA
    #  FNI_RMSE[i,] <- NA
    #}
    #else {
      reg1 <- lm(foliarN ~ FNIreg, na.action="na.omit")
      FNI_foliarN[i,] <- summary(reg1)$r.squared
      
      #get slope and y-intercept from linear regression
      b <- as.numeric(coef(reg1)[1])
      m <- as.numeric(coef(reg1)[2])
      #predict foliar N based on regression coefficients
      predN <- m*FNIreg + b 
      
      #calculate RMSE based on actual and predicted vals
      RMSE <- sqrt(mean((foliarN - predN)^2, na.rm=TRUE))
      FNI_RMSE[i,] <- RMSE
   # }
    setTxtProgressBar(pb, i)
  }



FNI_foliarN <- as.data.frame(FNI_foliarN)
FNI_RMSE <- as.data.frame(FNI_RMSE)
FNI_results <- cbind.data.frame(FNI_foliarN, FNI_RMSE)
rownames(FNI_results) <- FNIbandcombos$twoband #load this dataset below 

#save each biome seperately
all_res <- FNI_results
temp_res <- FNI_results
arid_res <- FNI_results
cont_res <- FNI_results
trop_res <- FNI_results

results_all <- cbind.data.frame(all_res, temp_res, arid_res, cont_res, trop_res)
colnames(results_all) <- c("all_r2", "all_RMSE", "temperate_R2", "temperate_RMSE", "arid_R2", "arid_RMSE", "continental_R2", "continental_RMSE", "tropical_R2", "tropical_RMSE")

results_all$biome_avgR2 <- rowMeans(results_all[,c(3,5,7,9)], na.rm=TRUE)
results_all$biome_avgRMSE <- rowMeans(results_all[,c(4,6,8,10)], na.rm=TRUE)
FNIbandcombos <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/bandcombos.csv")
b1 <- as.data.frame(strsplit(FNIbandcombos$band1, "nm", fixed=TRUE))
FNIbandcombos$twoband <- paste(b1, FNIbandcombos$band2, sep="-")
rownames(results_all) <- FNIbandcombos$twoband
summary(results_all$biome_avgR2)
summary(results_all$biome_avgRMSE)


write.csv(results_all, "C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI/2band_SAVI_R2andRMSE.csv")


####HEAT MAP####
dfvals <- cbind.data.frame(twobands,all_res[,1])
names(dfvals)[3] <- "FNIcor"
names(dfvals)[names(dfvals) == "1"] <- "band1"
names(dfvals)[names(dfvals) == "2"] <- "band2"

#reshape data so that in corr matrix structure with band 1 as columns and band 2 as rows
hmdata <- acast(dfvals, band1~band2, value.var="FNIcor")
hmdata <- as.data.frame(hmdata)

#add the wavelength regions that were excluded
#create vector of excluded bands
lambda1 <- seq(385,405, by=5)
lambda2 <- seq(1335,1455, by=5)
lambda3 <- seq(1795,2000, by=5)
lambda4 <- seq(2445, 2510, by=5)
lambda <- c(lambda1, lambda2, lambda3, lambda4)
lambda <- sub("$", "nm", lambda) 
#add "NA" columns
colNAs <-matrix(NA, nrow=length(hmdata), ncol=length(lambda))
colnames(colNAs) <- lambda
hm1 <- cbind.data.frame(hmdata, colNAs)
#add "NA" rows
rowNAs <- matrix(NA, nrow=length(lambda), ncol=length(hm1))
rownames(rowNAs) <- lambda
colnames(rowNAs) <- colnames(hm1)
hm2 <- rbind.data.frame(hm1, rowNAs)

#reorder data in wavelength order
lamnum <- rownames(hm2)
lamnum <- sub("nm", "", lamnum)
lamnum <- as.numeric(lamnum)
#assign the numeric wavelength as column and row names
rownames(hm2) <- lamnum
colnames(hm2) <- lamnum
#order the df in decending wavelength order
new_df <- hm2[ order(as.numeric(row.names(hm2))), ]
new_df <- new_df[,order(as.numeric(colnames(new_df)))]

#Hide lower triangle
hmfinal<-new_df
hmfinal[upper.tri(new_df, diag=TRUE)]<-""
#convert to form needed for heatmap (numeric matrix)
#hmfinal<-data.matrix(hmfinal)
hmfinal <- as.matrix(sapply(hmfinal, as.numeric))
write.csv(hmfinal, "C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI/SAVI_R2_all.csv")

#hmfinal <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI/NDVI_R2_tropical.csv")
#DO the HEAT MAP#
labvec <- c(rep(NA, 426))
labvec[c(4,44,84,124,164,204,244,284,324,364,404)] <- c(400,600,800,1000,1200,1400,1600,1800,2000,2200,2400)

#create color ramp for heat map
#redbluebrew <- colorRampPalette(brewer.pal(11,"RdBu"))(20)
inferno <- colorRampPalette(c("#fcffa4","#f98c0a", "#ba3655", "#550f6d", "#000004"))
lwid = c(1.5,4)
lhei = c(1.5,4)
#to put key underneath heatmap
lmat = rbind(4:3,2:1)

#create heat map of correlation coefficients for all 2-band indices
heatmap.2((hmfinal),dendrogram='none', Rowv=FALSE, na.rm=TRUE, distfun=FALSE,
          Colv=FALSE,trace='none', col=inferno, labRow=labvec, 
          labCol=labvec, srtCol=0, adjCol=c(0,-25),cexRow = 1.1, cexCol = 1.1,
          lmat = lmat, lwid = lwid, lhei = lhei, main="All Sites", breaks=seq(0,0.55, length.out=21),
          key=FALSE)
#for each ecosystem saved as .png image; width: 652 height: 471;
#labels:
heatmap.2((hmfinal),dendrogram='none', Rowv=FALSE, na.rm=TRUE, distfun=FALSE,
          Colv=FALSE,trace='none', col=inferno, labRow=labvec, 
          labCol=labvec, srtCol=0,cexRow = 1.1, cexCol = 1.1, offsetRow = -28,
          lmat = lmat, lwid = lwid, lhei = lhei, main="Tropical Sites",breaks=seq(0,0.55, length.out=21),
          key=TRUE, density.info="none", key.title = NA,
          key.xlab = "Correlation of Foliar N to FNI, R2", key.ylab = "Count",
          xlab= "Wavelength Band 2 (nm)", ylab="Wavelength Band 1 (nm)")

#min(hmfinal, na.rm=TRUE)
max(hmfinal, na.rm=TRUE)
mean(hmfinal, na.rm=TRUE)
median(hmfinal, na.rm=TRUE)




#######################DETERMINE THE 'BEST' 2-BAND COMBO#############
#picking up from line 63
#subset x biome
all <- regdata1
temperate <- subset(regdata1, biome== "Temperate")
arid <- subset(regdata1, biome== "Arid")
tropical <- subset(regdata1, biome== "Tropical")
continental <- subset(regdata1,biome== "Continental")


#create empty matrix to store correlations
FNI_foliarN <- matrix(NA, nrow=ncol(FNI), ncol=10)


#perform calcualte FNI for each 2 band combination and create correlation matrix of FNI:FoliarN
pb <- txtProgressBar(min = 2, max = ncol(FNI), style = 3)

combonum <- ncol(all)-2
for (i in 1:combonum){
  foliarN <- all[,1]
  FNI <- all[,-c(1:2)]
  foliarNcor <- (cor(FNI[,i], foliarN, use="pairwise.complete.obs"))^2
  FNI_foliarN[i,1] <- foliarNcor
  reg1 <- lm(FNI[,i] ~ foliarN)
  RSS <- c(crossprod(reg1$residuals))
  MSE <- RSS / length(reg1$residuals)
  RMSE <- sqrt(MSE)
  FNI_foliarN[i,2] <- RMSE
  
  foliarN <- temperate[,1]
  FNI <- temperate[,-c(1:2)]
  foliarNcor <- (cor(FNI[,i], foliarN, use="pairwise.complete.obs"))^2
  FNI_foliarN[i,3] <- foliarNcor
  reg1 <- lm(FNI[,i] ~ foliarN)
  RSS <- c(crossprod(reg1$residuals))
  MSE <- RSS / length(reg1$residuals)
  RMSE <- sqrt(MSE)
  FNI_foliarN[i,4] <- RMSE
  
  foliarN <- arid[,1]
  FNI <- arid[,-c(1:2)]
  foliarNcor <- (cor(FNI[,i], foliarN, use="pairwise.complete.obs"))^2
  FNI_foliarN[i,5] <- foliarNcor
  reg1 <- lm(FNI[,i] ~ foliarN)
  RSS <- c(crossprod(reg1$residuals))
  MSE <- RSS / length(reg1$residuals)
  RMSE <- sqrt(MSE)
  FNI_foliarN[i,6] <- RMSE
  
  foliarN <- continental[,1]
  FNI <- continental[,-c(1:2)]
  foliarNcor <- (cor(FNI[,i], foliarN, use="pairwise.complete.obs"))^2
  FNI_foliarN[i,7] <- foliarNcor
  reg1 <- lm(FNI[,i] ~ foliarN)
  RSS <- c(crossprod(reg1$residuals))
  MSE <- RSS / length(reg1$residuals)
  RMSE <- sqrt(MSE)
  FNI_foliarN[i,8] <- RMSE
  
  foliarN <- tropical[,1]
  FNI <- tropical[,-c(1:2)]
  foliarNcor <- (cor(FNI[,i], foliarN, use="pairwise.complete.obs"))^2
  FNI_foliarN[i,9] <- foliarNcor
  reg1 <- lm(FNI[,i] ~ foliarN)
  RSS <- c(crossprod(reg1$residuals))
  MSE <- RSS / length(reg1$residuals)
  RMSE <- sqrt(MSE)
  FNI_foliarN[i,10] <- RMSE
  
  setTxtProgressBar(pb, i)
}
FNI_foliarN <- as.data.frame(FNI_foliarN)
colnames(FNI_foliarN) <- c("all_r2", "all_RMSE", "temperate_R2", "temperate_RMSE", "arid_R2", "arid_RMSE", "continental_R2", "continental_RMSE", "tropical_R2", "tropical_RMSE")


FNI_foliarN$biome_avgR2 <- rowMeans(FNI_foliarN[,c(3,5,7,9)], na.rm=TRUE)
FNI_foliarN$biome_avgRMSE <- rowMeans(FNI_foliarN[,c(4,6,8,10)], na.rm=TRUE)
FNIbandcombos <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/bandcombos.csv")
b1 <- as.data.frame(strsplit(FNIbandcombos$band1, "nm", fixed=TRUE))
FNIbandcombos$twoband <- paste(b1, FNIbandcombos$band2, sep="-")
rownames(FNI_foliarN) <- FNIbandcombos$twoband

write.csv(FNI_foliarN, "C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI/2band_NDVI_R2andRMSE.csv")
