
data <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/oldanalysis.csv")
#exclude SRER samples
data <- subset(data, !siteID =="SRER")
#rename columns from band# to wavelength
ref <- data[,28:453]
#create wavelengths for bands
lambda <- seq(385,2510, by=5)
lambda <- sub("$", "nm", lambda) 
colnames(ref) <- lambda

#calculate various published foliar N indicies
data$chen <- (ref$`720nm`-ref$`700nm`)/(ref$`700nm`-ref$`670nm`)/(ref$`720nm`-ref$`670nm`+0.03)
data$clevers <- (ref$`780nm`/ref$`710nm`)-1
data$reyniers <- ((1.45*(ref$`800nm`)^2)+1) / (ref$`670nm`+0.45)
data$ndni <- ((log(1/ref$`1510nm`))-(log(1/ref$`1680nm`))) / ((log(1/ref$`1510nm`))+(log(1/ref$`1680nm`)))
data$tian <- ref$`430nm`/(ref$`495nm`+ref$`400nm`)
data$wang <- (ref$`900nm`-ref$`700nm`+2*ref$`420nm`)/(ref$`900nm`+ref$`700nm`-2*ref$`420nm`)
data$wei1 <- (1.5*(ref$`820nm`-ref$`735nm`))/(ref$`820nm`+ref$`735nm`+0.5)
data$wei2 <- ref$`820nm`/ref$`735nm`
data$xue <- ref$`810nm`/ref$`560nm`
data$zhu1 <- ref$`950nm`/ref$`660nm`
data$zhu2 <- ref$`870nm`/ref$`660nm`
data$zhu3 <- ref$`810nm`/ref$`660nm`
##this analysis FNI##
data$ndvi <- (ref$`2050nm` - ref$`2100nm`)/(ref$`2050nm` + ref$`2100nm`)
data$savi <- (1.5 * (ref$`2055nm` - ref$`2100nm`)) / (0.5 + ref$`2055nm` + ref$`2100nm`)
data$rvi <- ref$`2050nm` / ref$`2100nm`
#calculate average NIR
data$nir <- rowMeans(ref[,84:94]) #800:850
data$nir <- rowMeans(ref[,84:174]) #800:1250


#subset dataset
regdata <- data #all samples
regdata <- subset(data, biome=="Tropical") #subset x biome

#regdata$zhu3[is.infinite(regdata$zhu3)] <- NA

#regression analysis
#subset the predictor variable (independent varibale)
IV <- regdata$ndvi
#subset observed foliar N
observed <- regdata$ntrgnPr

reg1 <- lm(observed ~ IV)
output <- summary(reg1)
summary(reg1)
signif(output$r.squared, 3)


#get slope and y-intercept from linear regression
b <- as.numeric(coef(reg1)[1])
m <- as.numeric(coef(reg1)[2])
#predict foliar N based on regression coefficients
predN <- m*IV + b 
#calculate RMSE based on actual and observed vals
signif(sqrt (mean((observed - predN)^2)), 3)

