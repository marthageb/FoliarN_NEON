# code to create .shp files of herbaceous plant clips and woody samples. 
#First must dl the NDNI (Foliar N) data products from the NEON data portal 
###-- these provide the CRS information needed to georeference plant clip coords
#Also, must run 'plantclip_locations.R' to get coordinates of plant samples

library(raster)
library(ggplot2)
library(rgdal)
library(ggthemes)
library(multcompView)
library(colorspace)

#setwd
setwd("D:/martha/NEONpaper/")

#####load all NDNI NEON AOP products####
DEJU <- raster("AOPNDNI/DEJU/DEJU_foliarN.tif")
DSNY <- raster("AOPNDNI/DSNY/DSNY_foliarN.tif")
GUAN <- raster("AOPNDNI/GUAN/GUAN_foliarN.tif")
HARV <- raster("AOPNDNI/HARV/HARV_foliarN.tif")
JORN <- raster("AOPNDNI/JORN/JORN_foliarN.tif")
KONZ <- raster("AOPNDNI/KONZ/KONZ_foliarN.tif")
LENO <- raster("AOPNDNI/LENO/LENO_foliarN.tif")
MLBS <- raster("AOPNDNI/MLBS/MLBS_foliarN.tif")
MOAB <- raster("AOPNDNI/MOAB/MOAB_foliarN.tif")
OAES <- raster("AOPNDNI/OAES/OAES_foliarN.tif")
SCBI <- raster("AOPNDNI/SCBI/SCBI_foliarN.tif")
SOAP <- raster("AOPNDNI/SOAP/SOAP_foliarN.tif")
STEI_E <- raster("AOPNDNI/STEI/Eplots/STEI_foliarN.tif")
STEI_W <- raster("AOPNDNI/STEI/Wplots/STEI_foliarN.tif")
STER <- raster("AOPNDNI/STER/STER_foliarN.tif")
TALL <- raster("AOPNDNI/TALL/TALL_foliarN.tif")
TOOL <- raster("AOPNDNI/TOOL/TOOL_foliarN.tif")
UKFS <- raster("AOPNDNI/UKFS/UKFS_foliarN.tif")

#2019 samples#
CLBJ <- raster("AOPNDNI/CLBJ/CLBJ_foliarN.tif")
DELA <- raster("AOPNDNI/DELA/DELA_foliarN.tif")
PUUM <- raster("AOPNDNI/PUUM/PUUM_foliarN.tif")
SJER <- raster("AOPNDNI/SJER/SJER_foliarN.tif")
UNDE <- raster("AOPNDNI/UNDE/UNDE_foliarN.tif")
KONA <- raster("AOPNDNI/KONA/KONA_foliarN.tif")

BONA <- raster("AOPNDNI/BONA/BONA_NDVI.tif")
DCFS <- raster("AOPNDNI/DCFS/DCFS_NDVI.tif")
JERC <- raster("AOPNDNI/JERC/JERC_NDVI.tif")
NIWO <- raster("AOPNDNI/NIWO/NIWO_NDVI.tif")
WREF <- raster("AOPNDNI/WREF/WREF_NDVI.tif")

#####load plant clip location files (output from 'plantclip_locations.R'#####
herbs <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/herbs_foliarchem_locations.csv")
woody <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/woody_foliarchem_locations.csv")
# remove observations that don't have re-calculated lat/long coordinates
herbs <- herbs[complete.cases(herbs[,17:18]),]
woody <- woody[complete.cases(woody[,19:20]),]

######subset each of the plant clip dataframes by siteID so that projections can be defined#####
herbs$siteID <- as.factor(herbs$siteID)
woody$siteID <- as.factor(woody$siteID)
summary(herbs$siteID)
summary(woody$siteID)

dsny_herb <- subset(herbs, siteID =="DSNY")
jorn_herb <- subset(herbs, siteID =="JORN")
konz_herb <- subset(herbs, siteID =="KONZ")
moab_herb <- subset(herbs, siteID =="MOAB")
oaes_herb <- subset(herbs, siteID =="OAES")
#ornl_herb <- subset(herbs, siteID =="ORNL")
scbi_herb <- subset(herbs, siteID =="SCBI")
#serc_herb <- subset(herbs, siteID =="SERC")
soap_herb <- subset(herbs, siteID =="SOAP")
ster_herb <- subset(herbs, siteID =="STER")
tool_herb <- subset(herbs, siteID =="TOOL")
ukfs_herb <- subset(herbs, siteID =="UKFS")
#wood_herb <- subset(herbs, siteID =="WOOD")
clbj_herb <- subset(herbs, siteID=="CLBJ")
sjer_herb <- subset(herbs, siteID=="SJER")
kona_herb <- subset(herbs, siteID=="KONA")
dcfs_herb <- subset(herbs, siteID =="DCFS")
jerc_herb <- subset(herbs, siteID =="JERC")
niwo_herb <- subset(herbs, siteID =="NIWO")

deju_wood <- subset(woody, siteID=="DEJU")
dsny_wood <- subset(woody, siteID=="DSNY")
#grsm_wood <- subset(woody, siteID=="GRSM")
guan_wood <- subset(woody, siteID=="GUAN")
harv_wood <- subset(woody, siteID=="HARV")
jorn_wood <- subset(woody, siteID=="JORN")
konz_wood <- subset(woody, siteID=="KONZ")
leno_wood <- subset(woody, siteID=="LENO")
mlbs_wood <- subset(woody, siteID=="MLBS")
moab_wood <- subset(woody, siteID=="MOAB")
#ornl_wood <- subset(woody, siteID=="ORNL")
scbi_wood <- subset(woody, siteID=="SCBI")
#serc_wood <- subset(woody, siteID=="SERC")
soap_wood <- subset(woody, siteID=="SOAP")
stei_wood <- subset(woody, siteID=="STEI")
tall_wood <- subset(woody, siteID=="TALL")
ukfs_wood <- subset(woody, siteID=="UKFS")
clbj_wood <- subset(woody, siteID=="CLBJ")
dela_wood <- subset(woody, siteID=="DELA")
puum_wood <- subset(woody, siteID=="PUUM")
sjer_wood <- subset(woody, siteID=="SJER")
unde_wood <- subset(woody, siteID=="UNDE")
bona_wood <- subset(woody, siteID =="BONA")
jerc_wood <- subset(woody, siteID =="JERC")
niwo_wood <- subset(woody, siteID =="NIWO")
wref_wood <- subset(woody, siteID =="WREF")

#####convert plant clip location dataframes to spatialPoints object#####
##1.subset plant clip location dfs with x,y (northing and easting) coordinates
##2.define spatial coordinates to make a spatialPoints object 
##3.define projection of plant clip locations based on projection of the NDNI raster for that site
##steps 1-3 repeated for each site with both herb and woody plant samples.
dsny_herbxy <- dsny_herb
coordinates(dsny_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(dsny_herbxy) <- CRS('+proj=longlat +datum=WGS84')
dsny_herbxy <- spTransform(dsny_herbxy, proj4string(DSNY))
#raster::shapefile(dsny_herbxy, "./clip_locs/DSNYherb.shp")

jorn_herbxy <- jorn_herb
coordinates(jorn_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(jorn_herbxy) <- CRS('+proj=longlat +datum=WGS84')
jorn_herbxy <- spTransform(jorn_herbxy, proj4string(JORN))
#raster::shapefile(jorn_herbxy, "./clip_locs/JORNherb.shp")

konz_herbxy <- konz_herb
coordinates(konz_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(konz_herbxy) <- CRS('+proj=longlat +datum=WGS84')
konz_herbxy <- spTransform(konz_herbxy, proj4string(KONZ))
#raster::shapefile(konz_herbxy, "./clip_locs/KONZherb.shp")

moab_herbxy <- moab_herb
coordinates(moab_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(moab_herbxy) <- CRS('+proj=longlat +datum=WGS84')
moab_herbxy <- spTransform(moab_herbxy, proj4string(MOAB))
#raster::shapefile(moab_herbxy, "./clip_locs/MOABherb.shp")

oaes_herbxy <- oaes_herb
coordinates(oaes_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(oaes_herbxy) <- CRS('+proj=longlat +datum=WGS84')
oaes_herbxy <- spTransform(oaes_herbxy, proj4string(OAES))
#raster::shapefile(oaes_herbxy, "./clip_locs/OAESherb.shp")

#ornl_herbxy <- ornl_herb[,c(19,20)]
#coordinates(ornl_herbxy)= ~ easting + northing
#proj4string(ornl_herbxy) <- proj4string(ORNL)

scbi_herbxy <- scbi_herb
coordinates(scbi_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(scbi_herbxy) <- CRS('+proj=longlat +datum=WGS84')
scbi_herbxy <- spTransform(scbi_herbxy, proj4string(SCBI))
#raster::shapefile(scbi_herbxy, "./clip_locs/SCBIherb.shp")

#serc_herbxy <- serc_herb[,c(19,20)]
#coordinates(serc_herbxy)= ~ easting + northing
#proj4string(serc_herbxy) <- proj4string(SERC)

soap_herbxy <- soap_herb
coordinates(soap_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(soap_herbxy) <- CRS('+proj=longlat +datum=WGS84')
soap_herbxy <- spTransform(soap_herbxy, proj4string(SOAP))
#raster::shapefile(soap_herbxy, "./clip_locs/SOAPherb.shp")

ster_herbxy <- ster_herb
coordinates(ster_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(ster_herbxy) <- CRS('+proj=longlat +datum=WGS84')
ster_herbxy <- spTransform(ster_herbxy, proj4string(STER))
#raster::shapefile(ster_herbxy, "./clip_locs/STERherb.shp")

tool_herbxy <- tool_herb
coordinates(tool_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(tool_herbxy) <- CRS('+proj=longlat +datum=WGS84')
tool_herbxy <- spTransform(tool_herbxy, proj4string(TOOL))
#raster::shapefile(tool_herbxy, "./clip_locs/TOOLherb.shp")

ukfs_herbxy <- ukfs_herb
coordinates(ukfs_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(ukfs_herbxy) <- CRS('+proj=longlat +datum=WGS84')
ukfs_herbxy <- spTransform(ukfs_herbxy, proj4string(UKFS))
#raster::shapefile(ukfs_herbxy, "./clip_locs/UKFSherb.shp")

#wood_herbxy <- wood_herb[,c(19,20)]
#coordinates(wood_herbxy)= ~ easting + northing
#proj4string(wood_herbxy) <- proj4string(WOOD)

clbj_herbxy <- clbj_herb
coordinates(clbj_herbxy)=  ~ decimalLongitude + decimalLatitude
proj4string(clbj_herbxy) <- CRS('+proj=longlat +datum=WGS84')
clbj_herbxy <- spTransform(clbj_herbxy, proj4string(CLBJ))


sjer_herbxy <- sjer_herb
coordinates(sjer_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(sjer_herbxy) <- CRS('+proj=longlat +datum=WGS84')
sjer_herbxy <- spTransform(sjer_herbxy, proj4string(SJER))

kona_herbxy <- kona_herb
coordinates(kona_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(kona_herbxy) <- CRS('+proj=longlat +datum=WGS84')
kona_herbxy <- spTransform(kona_herbxy, proj4string(KONA))

dcfs_herbxy <- dcfs_herb
coordinates(dcfs_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(dcfs_herbxy) <- CRS('+proj=longlat +datum=WGS84')
dcfs_herbxy <- spTransform(dcfs_herbxy, proj4string(DCFS))

jerc_herbxy <- jerc_herb
coordinates(jerc_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(jerc_herbxy) <- CRS('+proj=longlat +datum=WGS84')
jerc_herbxy <- spTransform(jerc_herbxy, proj4string(JERC))

niwo_herbxy <- niwo_herb
coordinates(niwo_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(niwo_herbxy) <- CRS('+proj=longlat +datum=WGS84')
niwo_herbxy <- spTransform(niwo_herbxy, proj4string(NIWO))


#-------------WOODY SAMPLES-----------#
#woody samples
deju_woodxy <- deju_wood
coordinates(deju_woodxy)= ~ adjEasting + adjNorthing
proj4string(deju_woodxy) <- proj4string(DEJU)
#raster::shapefile(deju_woodxy, "./clip_locs/DEJUwood.shp")

dsny_woodxy <- dsny_wood
coordinates(dsny_woodxy)= ~ adjEasting + adjNorthing
proj4string(dsny_woodxy) <- proj4string(DSNY)
#raster::shapefile(dsny_woodxy, "./clip_locs/DSNYwood.shp")

#grsm_woodxy <- grsm_wood[,c(16,17)]
#coordinates(grsm_woodxy)= ~ adjEasting + adjNorthing
#proj4string(grsm_woodxy) <- proj4string(GRSM)

guan_woodxy <- guan_wood
coordinates(guan_woodxy)= ~ adjEasting + adjNorthing
proj4string(guan_woodxy) <- proj4string(GUAN)
#raster::shapefile(guan_woodxy, "./clip_locs/GUANwood.shp")

harv_woodxy <- harv_wood
coordinates(harv_woodxy)= ~ adjEasting + adjNorthing
proj4string(harv_woodxy) <- proj4string(HARV)
#raster::shapefile(harv_woodxy, "./clip_locs/HARVwood.shp")

jorn_woodxy <- jorn_wood
coordinates(jorn_woodxy)= ~ adjEasting + adjNorthing
proj4string(jorn_woodxy) <- proj4string(JORN)
#raster::shapefile(jorn_woodxy, "./clip_locs/JORNwood.shp")

konz_woodxy <- konz_wood
coordinates(konz_woodxy)= ~ adjEasting + adjNorthing
proj4string(konz_woodxy) <- proj4string(KONZ)
#raster::shapefile(konz_woodxy, "./clip_locs/KONZwood.shp")

leno_woodxy <- leno_wood
coordinates(leno_woodxy)= ~ adjEasting + adjNorthing
proj4string(leno_woodxy) <- proj4string(LENO)
#raster::shapefile(leno_woodxy, "./clip_locs/LENOwood.shp")

mlbs_woodxy <- mlbs_wood
coordinates(mlbs_woodxy)= ~ adjEasting + adjNorthing
proj4string(mlbs_woodxy) <- proj4string(MLBS)
#raster::shapefile(mlbs_woodxy, "./clip_locs/MLBSwood.shp")

moab_woodxy <- moab_wood
coordinates(moab_woodxy)= ~ adjEasting + adjNorthing
proj4string(moab_woodxy) <- proj4string(MOAB)
#raster::shapefile(moab_woodxy, "./clip_locs/MOABwood.shp")

#ornl_woodxy <- ornl_wood[,c(16,17)]
#coordinates(ornl_woodxy)= ~ adjEasting + adjNorthing
#proj4string(ornl_woodxy) <- proj4string(ORNL)

scbi_woodxy <- scbi_wood
coordinates(scbi_woodxy)= ~ adjEasting + adjNorthing
proj4string(scbi_woodxy) <- proj4string(SCBI)
#raster::shapefile(scbi_woodxy, "./clip_locs/SCBIwood.shp")

#serc_woodxy <- serc_wood[,c(16,17)]
#coordinates(serc_woodxy)= ~ adjEasting + adjNorthing
#proj4string(serc_woodxy) <- proj4string(SERC)

soap_woodxy <- soap_wood
coordinates(soap_woodxy)= ~ adjEasting + adjNorthing
proj4string(soap_woodxy) <- proj4string(SOAP)
#raster::shapefile(soap_woodxy, "./clip_locs/SOAPwood.shp")

stei_woodE <- subset(stei_wood, utmZone== "16N")
stei_woodW <- subset(stei_wood, utmZone== "15N")
stei_woodExy <- stei_woodE
coordinates(stei_woodExy)= ~ adjEasting + adjNorthing
proj4string(stei_woodExy) <- proj4string(STEI_E)
#raster::shapefile(stei_woodExy, "./clip_locs/STEI_Ewood.shp")
stei_woodWxy <- stei_woodW
coordinates(stei_woodWxy)= ~ adjEasting + adjNorthing
proj4string(stei_woodWxy) <- proj4string(STEI_W)
#raster::shapefile(stei_woodWxy, "./clip_locs/STEI_Wwood.shp")

tall_woodxy <- tall_wood
coordinates(tall_woodxy)= ~ adjEasting + adjNorthing
proj4string(tall_woodxy) <- proj4string(TALL)
#raster::shapefile(tall_woodxy, "./clip_locs/TALLwood.shp")

ukfs_woodxy <- ukfs_wood
coordinates(ukfs_woodxy)= ~ adjEasting + adjNorthing
proj4string(ukfs_woodxy) <- proj4string(UKFS)
#raster::shapefile(ukfs_woodxy, "./clip_locs/UKFSwood.shp")

clbj_woodxy <- clbj_wood
coordinates(clbj_woodxy)= ~ adjEasting + adjNorthing
proj4string(clbj_woodxy) <- proj4string(CLBJ)

dela_woodxy <- dela_wood
coordinates(dela_woodxy)= ~ adjEasting + adjNorthing
proj4string(dela_woodxy) <- proj4string(DELA)

puum_woodxy <- puum_wood
coordinates(puum_woodxy)= ~ adjEasting + adjNorthing
proj4string(puum_woodxy) <- proj4string(PUUM)

sjer_woodxy <- sjer_wood
coordinates(sjer_woodxy)= ~ adjEasting + adjNorthing
proj4string(sjer_woodxy) <- proj4string(SJER)

unde_woodxy <- unde_wood
coordinates(unde_woodxy)= ~ adjEasting + adjNorthing
proj4string(unde_woodxy) <- proj4string(UNDE)

bona_woodxy <- bona_wood
coordinates(bona_woodxy)= ~ adjEasting + adjNorthing
proj4string(bona_woodxy) <- proj4string(BONA)

jerc_woodxy <- jerc_wood
coordinates(jerc_woodxy)= ~ adjEasting + adjNorthing
proj4string(jerc_woodxy) <- proj4string(JERC)

niwo_woodxy <- niwo_wood
coordinates(niwo_woodxy)= ~ adjEasting + adjNorthing
proj4string(niwo_woodxy) <- proj4string(NIWO)

wref_woodxy <- wref_wood
coordinates(wref_woodxy)= ~ adjEasting + adjNorthing
proj4string(wref_woodxy) <- proj4string(WREF)

#####extract herbaceous plant sample AOP NDNI (Foliar N) values for all sites######
DSNYherbs <- raster::extract(DSNY, dsny_herbxy, df=T, buffer=2, fun=mean)
DSNYherbs$clipID <- dsny_herb$clipID
DSNYherbs <- DSNYherbs[complete.cases(DSNYherbs),]
names(DSNYherbs) <- c('ID', 'foliarN', 'clipID')

JORNherbs <- raster::extract(JORN, jorn_herbxy, df=T, buffer=2, fun=mean)
JORNherbs$clipID <- jorn_herb$clipID
JORNherbs <- JORNherbs[complete.cases(JORNherbs),]
names(JORNherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(DSNYherbs,JORNherbs)
oldAOP <- AOPherbs

KONZherbs <- raster::extract(KONZ, konz_herbxy, df=T, buffer=2, fun=mean)
KONZherbs$clipID <- konz_herb$clipID
KONZherbs <- KONZherbs[complete.cases(KONZherbs),]
names(KONZherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,KONZherbs)
oldAOP <- AOPherbs

MOABherbs <- raster::extract(MOAB, moab_herbxy, df=T, buffer=2, fun=mean)
MOABherbs$clipID <- moab_herb$clipID
MOABherbs <- MOABherbs[complete.cases(MOABherbs),]
names(MOABherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,MOABherbs)
oldAOP <- AOPherbs

OAESherbs <- raster::extract(OAES, oaes_herbxy, df=T, buffer=2, fun=mean)
OAESherbs$clipID <- oaes_herb$clipID
OAESherbs <- OAESherbs[complete.cases(OAESherbs),]
names(OAESherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,OAESherbs)
oldAOP <- AOPherbs

SCBIherbs <- raster::extract(SCBI, scbi_herbxy, df=T, buffer=2, fun=mean)
SCBIherbs$clipID <- scbi_herb$clipID
SCBIherbs <- SCBIherbs[complete.cases(SCBIherbs),]
names(SCBIherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,SCBIherbs)
oldAOP <- AOPherbs

SOAPherbs <- raster::extract(SOAP, soap_herbxy, df=T, buffer=2, fun=mean)
SOAPherbs$clipID <- soap_herb$clipID
SOAPherbs <- SOAPherbs[complete.cases(SOAPherbs),]
names(SOAPherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,SOAPherbs)
oldAOP <- AOPherbs

STERherbs <- raster::extract(STER, ster_herbxy, df=T, buffer=2, fun=mean)
STERherbs$clipID <- ster_herb$clipID
STERherbs <- STERherbs[complete.cases(STERherbs),]
names(STERherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,STERherbs)
oldAOP <- AOPherbs

TOOLherbs <- raster::extract(TOOL, tool_herbxy, df=T, buffer=2, fun=mean)
TOOLherbs$clipID <- tool_herb$clipID
TOOLherbs <- TOOLherbs[complete.cases(TOOLherbs),]
names(TOOLherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,TOOLherbs)
oldAOP <- AOPherbs

UKFSherbs <- raster::extract(UKFS, ukfs_herbxy, df=T, buffer=2, fun=mean)
UKFSherbs$clipID <- ukfs_herb$clipID
UKFSherbs <- UKFSherbs[complete.cases(UKFSherbs),]
names(UKFSherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,UKFSherbs)
oldAOP <- AOPherbs

CLBJherbs <- raster::extract(CLBJ, clbj_herbxy, df=T, buffer=2, fun=mean)
CLBJherbs$clipID <- clbj_herb$clipID
CLBJherbs <- CLBJherbs[complete.cases(CLBJherbs),]
names(CLBJherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,CLBJherbs)
oldAOP <- AOPherbs

SJERherbs <- raster::extract(SJER, sjer_herbxy, df=T, buffer=2, fun=mean)
SJERherbs$clipID <- sjer_herb$clipID
SJERherbs <- SJERherbs[complete.cases(SJERherbs),]
names(SJERherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,SJERherbs)
oldAOP <- AOPherbs

KONAherbs <- raster::extract(KONA, kona_herbxy, df=T, buffer=2, fun=mean)
KONAherbs$clipID <- kona_herb$clipID
KONAherbs <- KONAherbs[complete.cases(KONAherbs),]
names(KONAherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,KONAherbs)
oldAOP <- AOPherbs

DCFSherbs <- raster::extract(DCFS, dcfs_herbxy, df=T, buffer=2, fun=mean)
DCFSherbs$clipID <- dcfs_herb$clipID
DCFSherbs <- DCFSherbs[complete.cases(DCFSherbs),]
names(DCFSherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,DCFSherbs)
oldAOP <- AOPherbs

JERCherbs <- raster::extract(JERC, jerc_herbxy, df=T, buffer=2, fun=mean)
JERCherbs$clipID <- jerc_herb$clipID
JERCherbs <- JERCherbs[complete.cases(JERCherbs),]
names(JERCherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,JERCherbs)
oldAOP <- AOPherbs

NIWOherbs <- raster::extract(NIWO, niwo_herbxy, df=T, buffer=2, fun=mean)
NIWOherbs$clipID <- niwo_herb$clipID
NIWOherbs <- NIWOherbs[complete.cases(NIWOherbs),]
names(NIWOherbs) <- c('ID', 'foliarN', 'clipID')

AOPherbs <- rbind(oldAOP,NIWOherbs)
oldAOP <- AOPherbs


herbs_AOPN <- merge(AOPherbs,herbs, by="clipID")


##GET EASTING AND NORTHING COORDS###
clbj_en <- as.data.frame(clbj_herbxy)
clbj_en <- clbj_en[,c(2,22,23)]
colnames(clbj_en) <- c("clipID", "adjEasting", "adjNorthing")

dsny_en <- as.data.frame(dsny_herbxy)
dsny_en <- dsny_en[,c(2,22,23)]
colnames(dsny_en) <- c("clipID", "adjEasting", "adjNorthing")

jorn_en <- as.data.frame(jorn_herbxy)
jorn_en <- jorn_en[,c(2,22,23)]
colnames(jorn_en) <- c("clipID", "adjEasting", "adjNorthing")

kona_en <- as.data.frame(kona_herbxy)
kona_en <- kona_en[,c(2,22,23)]
colnames(kona_en) <- c("clipID", "adjEasting", "adjNorthing")

konz_en <- as.data.frame(konz_herbxy)
konz_en <- konz_en[,c(2,22,23)]
colnames(konz_en) <- c("clipID", "adjEasting", "adjNorthing")

moab_en <- as.data.frame(moab_herbxy)
moab_en <- moab_en[,c(2,22,23)]
colnames(moab_en) <- c("clipID", "adjEasting", "adjNorthing")

oaes_en <- as.data.frame(oaes_herbxy)
oaes_en <- oaes_en[,c(2,22,23)]
colnames(oaes_en) <- c("clipID", "adjEasting", "adjNorthing")

#ornl_en <- as.data.frame(ornl_herbxy)
#ornl_en <- ornl_en[,c(2,22,23)]
#colnames(ornl_en) <- c("clipID", "adjEasting", "adjNorthing")

scbi_en <- as.data.frame(scbi_herbxy)
scbi_en <- scbi_en[,c(2,22,23)]
colnames(scbi_en) <- c("clipID", "adjEasting", "adjNorthing")

#serc_en <- as.data.frame(serc_herbxy)
#serc_en <- serc_en[,c(2,22,23)]
#colnames(serc_en) <- c("clipID", "adjEasting", "adjNorthing")

sjer_en <- as.data.frame(sjer_herbxy)
sjer_en <- sjer_en[,c(2,22,23)]
colnames(sjer_en) <- c("clipID", "adjEasting", "adjNorthing")

soap_en <- as.data.frame(soap_herbxy)
soap_en <- soap_en[,c(2,22,23)]
colnames(soap_en) <- c("clipID", "adjEasting", "adjNorthing")

ster_en <- as.data.frame(ster_herbxy)
ster_en <- ster_en[,c(2,22,23)]
colnames(ster_en) <- c("clipID", "adjEasting", "adjNorthing")

tool_en <- as.data.frame(tool_herbxy)
tool_en <- tool_en[,c(2,22,23)]
colnames(tool_en) <- c("clipID", "adjEasting", "adjNorthing")

ukfs_en <- as.data.frame(ukfs_herbxy)
ukfs_en <- ukfs_en[,c(2,22,23)]
colnames(ukfs_en) <- c("clipID", "adjEasting", "adjNorthing")

#wood_en <- as.data.frame(wood_herbxy)
#wood_en <- wood_en[,c(2,22,23)]
#colnames(wood_en) <- c("clipID", "adjEasting", "adjNorthing")

dcfs_en <- as.data.frame(dcfs_herbxy)
dcfs_en <- dcfs_en[,c(2,22,23)]
colnames(dcfs_en) <- c("clipID", "adjEasting", "adjNorthing")

jerc_en <- as.data.frame(jerc_herbxy)
jerc_en <- jerc_en[,c(2,22,23)]
colnames(jerc_en) <- c("clipID", "adjEasting", "adjNorthing")

niwo_en <- as.data.frame(niwo_herbxy)
niwo_en <- niwo_en[,c(2,22,23)]
colnames(niwo_en) <- c("clipID", "adjEasting", "adjNorthing")

en <- rbind.data.frame(clbj_en, dsny_en, jorn_en, kona_en, konz_en, moab_en, oaes_en, scbi_en,
                       sjer_en, soap_en, ster_en, tool_en, ukfs_en, dcfs_en, jerc_en, niwo_en)

herbs_AOPN <- merge(herbs_AOPN, en, by="clipID")

#write.csv(herbs_AOPN, "./data/dataSept2020/herbs_NDNI.csv")

#####extract woody plant sample AOP NDNI (Foliar N) values for all sites######
DEJUwood <- raster::extract(DEJU, deju_woodxy, df=T)
DEJUwood$individualID <-  deju_wood$individualID
DEJUwood <- DEJUwood[complete.cases(DEJUwood),]
names(DEJUwood) <- c('ID', 'NDNI', 'individualID')

DSNYwood <- raster::extract(DSNY, dsny_woodxy, df=T)
DSNYwood$individualID <-  dsny_wood$individualID
DSNYwood <- DSNYwood[complete.cases(DSNYwood),]
names(DSNYwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(DEJUwood,DSNYwood)
oldAOP <- AOPwood

GUANwood <- raster::extract(GUAN, guan_woodxy, df=T)
GUANwood$individualID <-  guan_wood$individualID
GUANwood <- GUANwood[complete.cases(GUANwood),]
names(GUANwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,GUANwood)
oldAOP <- AOPwood

HARVwood <- raster::extract(HARV, harv_woodxy, df=T)
HARVwood$individualID <-  harv_wood$individualID
HARVwood <- HARVwood[complete.cases(HARVwood),]
names(HARVwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,HARVwood)
oldAOP <- AOPwood

JORNwood <- raster::extract(JORN, jorn_woodxy, df=T)
JORNwood$individualID <-  jorn_wood$individualID
JORNwood <- JORNwood[complete.cases(JORNwood),]
names(JORNwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,JORNwood)
oldAOP <- AOPwood

KONZwood <- raster::extract(KONZ, konz_woodxy, df=T)
KONZwood$individualID <- konz_wood$individualID
KONZwood <- KONZwood[complete.cases(KONZwood),]
names(KONZwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,KONZwood)
oldAOP <- AOPwood

LENOwood <- raster::extract(LENO, leno_woodxy, df=T)
LENOwood$individualID <- leno_wood$individualID
LENOwood <- LENOwood[complete.cases(LENOwood),]
names(LENOwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,LENOwood)
oldAOP <- AOPwood

MLBSwood <- raster::extract(MLBS, mlbs_woodxy, df=T)
MLBSwood$individualID <- mlbs_wood$individualID
MLBSwood <- MLBSwood[complete.cases(MLBSwood),]
names(MLBSwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,MLBSwood)
oldAOP <- AOPwood

MOABwood <- raster::extract(MOAB, moab_woodxy, df=T)
MOABwood$individualID <- moab_wood$individualID
MOABwood <- MOABwood[complete.cases(MOABwood),]
names(MOABwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,MOABwood)
oldAOP <- AOPwood

SCBIwood <- raster::extract(SCBI, scbi_woodxy, df=T)
SCBIwood$individualID <- scbi_wood$individualID
SCBIwood <- SCBIwood[complete.cases(SCBIwood),]
names(SCBIwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,SCBIwood)
oldAOP <- AOPwood

SOAPwood <- raster::extract(SOAP, soap_woodxy, df=T)
SOAPwood$individualID <- soap_wood$individualID
SOAPwood <- SOAPwood[complete.cases(SOAPwood),]
names(SOAPwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,SOAPwood)
oldAOP <- AOPwood

STEI_Ewood <- raster::extract(STEI_E, stei_woodExy, df=T)
STEI_Ewood$individualID <- stei_woodE$individualID
STEI_Ewood <- STEI_Ewood[complete.cases(STEI_Ewood),]
names(STEI_Ewood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,STEI_Ewood)
oldAOP <- AOPwood

STEI_Wwood <- raster::extract(STEI_W, stei_woodWxy, df=T)
STEI_Wwood$individualID <- stei_woodW$individualID
STEI_Wwood <- STEI_Wwood[complete.cases(STEI_Wwood),]
names(STEI_Wwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,STEI_Wwood)
oldAOP <- AOPwood

TALL_wood <- raster::extract(TALL, tall_woodxy, df=T)
TALL_wood$individualID <- tall_wood$individualID
TALL_wood <- TALL_wood[complete.cases(TALL_wood),]
names(TALL_wood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,TALL_wood)
oldAOP <- AOPwood

UKFS_wood <- raster::extract(UKFS, ukfs_woodxy, df=T)
UKFS_wood$individualID <- ukfs_wood$individualID
UKFS_wood <- UKFS_wood[complete.cases(UKFS_wood),]
names(UKFS_wood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,UKFS_wood)
oldAOP <- AOPwood

CLBJ_wood <- raster::extract(CLBJ, clbj_woodxy, df=T)
CLBJ_wood$individualID <- clbj_wood$individualID
CLBJ_wood <- CLBJ_wood[complete.cases(CLBJ_wood),]
names(CLBJ_wood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,CLBJ_wood)
oldAOP <- AOPwood

DELA_wood <- raster::extract(DELA, dela_woodxy, df=T)
DELA_wood$individualID <- dela_wood$individualID
DELA_wood <- DELA_wood[complete.cases(DELA_wood),]
names(DELA_wood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,DELA_wood)
oldAOP <- AOPwood

PUUM_wood <- raster::extract(PUUM, puum_woodxy, df=T)
PUUM_wood$individualID <- puum_wood$individualID
PUUM_wood <- PUUM_wood[complete.cases(PUUM_wood),]
names(PUUM_wood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,PUUM_wood)
oldAOP <- AOPwood

SJER_wood <- raster::extract(SJER, sjer_woodxy, df=T)
SJER_wood$individualID <- sjer_wood$individualID
SJER_wood <- SJER_wood[complete.cases(SJER_wood),]
names(SJER_wood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,SJER_wood)
oldAOP <- AOPwood

UNDE_wood <- raster::extract(UNDE, unde_woodxy, df=T)
UNDE_wood$individualID <- unde_wood$individualID
UNDE_wood <- UNDE_wood[complete.cases(UNDE_wood),]
names(UNDE_wood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,UNDE_wood)
oldAOP <- AOPwood


BONAwood <- raster::extract(BONA, bona_woodxy, df=T)
BONAwood$individualID <-  bona_wood$individualID
BONAwood <- BONAwood[complete.cases(BONAwood),]
names(BONAwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,BONAwood)
oldAOP <- AOPwood

JERCwood <- raster::extract(JERC, jerc_woodxy, df=T)
JERCwood$individualID <-  jerc_wood$individualID
JERCwood <- JERCwood[complete.cases(JERCwood),]
names(JERCwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,JERCwood)
oldAOP <- AOPwood

NIWOwood <- raster::extract(NIWO, niwo_woodxy, df=T)
NIWOwood$individualID <-  niwo_wood$individualID
NIWOwood <- NIWOwood[complete.cases(NIWOwood),]
names(NIWOwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,NIWOwood)
oldAOP <- AOPwood

WREFwood <- raster::extract(WREF, wref_woodxy, df=T)
WREFwood$individualID <-  wref_wood$individualID
WREFwood <- WREFwood[complete.cases(WREFwood),]
names(WREFwood) <- c('ID', 'NDNI', 'individualID')

AOPwood <- rbind(oldAOP,WREFwood)

woody_AOPN <- merge(AOPwood, woody, by="individualID")


library(dplyr)
# remove duplicate values wherever they exist. take means for numeric variables, else first observation. 
ndniwoody <- woody_AOPN  %>%
  group_by(individualID) %>%
  summarise_all(list( ~ if (is.numeric(.)) {
    mean(., na.rm = TRUE)
  } else {
    first(.)
  }))

#write.csv(ndniwoody, "./data/dataSept2020/woody_NDNI.csv")

#delete the extra columns in the datasets
woody <- woody_AOPN[,c(5,1,16,8,9:15,17,21,22,19,20,3)]
herbs <- herbs_AOPN[,c(5,16,1,8,9:15,17,21,22,27,26,18:20,3)]

#rename  columns
names(herbs)[names(herbs) == "foliarN"] <- "NDNI"
names(herbs)[names(herbs) == "decimalLatitude"] <- "adjDecimalLatitude"
names(herbs)[names(herbs) == "decimalLongitude"] <- "adjDecimalLongitude"

#add extra columns to match up between the 2 datasets
woody$clipLength <- NA
woody$clipWidth <- NA
woody$percentCoverClip <- NA

#subset herb clips so that %cover is >= 85%
highcov <- subset(herbs, percentCoverClip >= 85)

#combine the woody and herbaceous samples into a single df
regdata <- rbind(woody,highcov)

#WRITE DATA
write.csv(regdata,"C:/Users/farellam/Documents/FoliarN_NEON/data/foliarchem_locs_allsites.csv")


meta <- regdata %>% group_by(siteID, sampleType) %>% summarize(n =n())

#####make kml#### 
setwd("C:/Users/farellam/Documents/FoliarN_NEON/data")
wref <- wref_wood
coordinates(wref) <- ~ adjDecimalLongitude + adjDecimalLatitude
proj4string(wref) <- CRS('+proj=longlat +datum=WGS84')
writeOGR(wref["individualID"], layer="individualID", 'wref_wood.kml', driver="KML")

sites <- readOGR("C:/Users/farellam/Documents/FoliarN_NEON/data/kml/jerc_herb.kml")
plot(sites)
sites2 <- readOGR("C:/Users/farellam/Documents/FoliarN_NEON/data/kml/jerc_wood.kml")
plot(sites2, add=TRUE)



kona_herbxy <- kona_herb
coordinates(kona_herbxy)= ~ decimalLongitude + decimalLatitude
proj4string(kona_herbxy) <- CRS('+proj=longlat +datum=WGS84')
######################################################################################################################
######################################################################################################################
######################################################################################################################
######################################################################################################################
######################################################################################################################


#######create a shp file of the regression data##############
plantlocs <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/foliarchem_locs_allsites.csv")
#make a column IDing training/testing sites
plantlocs$type <- rep("training", nrow=nrow(plantlocs))
plantlocs$type[plantlocs$siteID %in% c("BONA", "JERC", "NIWO", "WREF")] <- "testing"
coordinates(plantlocs) = ~ adjDecimalLongitude + adjDecimalLatitude
proj4string(plantlocs)<- CRS("+proj=latlong +datum=WGS84 +units=m +nodefs") # set coordinate system to WGS
raster::shapefile(plantlocs, "C:/Users/farellam/Documents/FoliarN_NEON/data/shp_files/allsamples_pts.shp", overwrite=TRUE)

#subset for each utmzone
zone <- subset(regdata, siteID %in% c("GUAN"))
coordinates(zone) = ~ adjEasting + adjNorthing
proj4string(zone)<- CRS("+proj=utm +zone=19 +datum=WGS84 +units=m +nodefs") # set coordinate system to WGS
raster::shapefile(zone, "C:/Users/farellam/Documents/FoliarN_NEON/data/shp_files/zone19N.shp", overwrite=TRUE)
