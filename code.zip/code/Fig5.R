
library(reshape2)
library(RColorBrewer)
library(gplots)

setwd("C:/Users/farellam/Documents/FoliarN_NEON/Results/FNI")

#read the PLSR results-- output from 'PLSRloop.R'
results <- read.csv("all_RVI_PLSRresults.csv")
coeff.frame <- read.csv("all_RVI_PLSRcoef.csv")
VIP.frame <- read.csv("all_RVI_PLSR_VIP.csv")
#VIP.frame <- VIP.frame[,-1]

#get the 2-band combos this "biome" df is from line 286 PLSRloop.R
#FNIbandcombos <- colnames(regdata1[,3:115262])
##############good results are already saved so the next section isn't needed######
results <- results[complete.cases(results), ]
rownames(results) <- results$X

mean(results$trainr2)
mean(results$trainRMSE)
mean(results$testr2)
mean(results$testRMSE)

# create df of results where [R2 validation > avg R2] and [RMSE validation < avg RMSE] (per Chadwick & Asner 2016 RSE)
goodmodel <- subset(results, testRMSE < mean(testRMSE))
goodmodel <- subset(goodmodel, testr2 > mean(results$testr2))

#subset the regression coefficients and VIP values for only the "good runs"
goodruns <- as.numeric(rownames(goodmodel))
rownames(coeff.frame) <- c("intercept", FNIbandcombos)
coeff.frame <- coeff.frame[,-1]
VIP.frame <-VIP.frame[,-1]

goodcoeff <- coeff.frame[,c(goodruns)]
goodVIP <- VIP.frame[,c(goodruns)]
###################
goodVIP <- VIP.frame
goodcoeff <- coeff.frame
goodcoeff <- goodcoeff[,-1]
goodVIP <- goodVIP[,-1]
FNIbandcombos <- read.csv("C:/Users/farellam/Documents/FoliarN_NEON/data/bandcombos.csv")
FNIbandcombos <- paste(FNIbandcombos$band1, FNIbandcombos$band2, sep="-")
rownames(goodcoeff) <- c("intercept", FNIbandcombos)

##############COEFFICIENT VALUES HEAT GRAPH###########
###compute average corr coeff values and restructure data so that it is in correlation matrix format for heatmap
rn <- as.character(rownames(goodcoeff))
twobands <- do.call(rbind, strsplit(rn, '-'))

#perform a t.test to determine the average values for each run are sig. different from zero for each 2 band combo
#create blank dataframe to hold average values when sig. diff from 0, else do "NA"
avgcoeff <- matrix(NA, nrow=nrow(goodcoeff), ncol=1)
avgcoeff <- as.data.frame(avgcoeff)

pb <- txtProgressBar(min = 1, max = nrow(goodcoeff), style = 3)

for (i in 1:nrow(goodcoeff)){
  coefttest <- t.test(goodcoeff[i,], mu=0, alternative = "two.sided")
  pval <- coefttest$p.value
  if (pval < 0.05){
    avgcoeff[i,] <- rowMeans(goodcoeff[i,])
  } else {
    avgcoeff[i,] <- "NA"
  }
  setTxtProgressBar(pb, i)
}
#takes about 10 mins for 117,306 band combinations, over 42 "runs"

#rename calcualted avg coeff
avgcoeff$avgcoeff <- avgcoeff$V1
avgcoeff$avgcoeff <- as.numeric(avgcoeff$avgcoeff)

#cbind band1, band2, and avg coeff into a new df
dfvals <- cbind.data.frame(twobands,avgcoeff$avgcoeff)
names(dfvals)[names(dfvals) == "avgcoeff$avgcoeff"] <- "avgcoeff"
names(dfvals)[names(dfvals) == "1"] <- "band1"
names(dfvals)[names(dfvals) == "2"] <- "band2"


#reshape data so that in corr matrix structure with band 1 as columns and band 2 as rows
hmdata <- acast(dfvals, band1~band2, value.var="avgcoeff")
hmdata <- as.data.frame(hmdata)

#add the wavelength regions that were excluded
#create vector of excluded bands
lambda1 <- seq(385,405, by=5)
lambda2 <- seq(1335,1455, by=5)
lambda3 <- seq(1795,2000, by=5)
lambda4 <- seq(2445, 2510, by=5)
lambda <- c(lambda1, lambda2, lambda3, lambda4)
lambda <- sub("$", "nm", lambda) 
#add "NA" columns
colNAs <-matrix(NA, nrow=length(hmdata), ncol=length(lambda))
colnames(colNAs) <- lambda
hm1 <- cbind.data.frame(hmdata, colNAs)
#add "NA" rows
rowNAs <- matrix(NA, nrow=length(lambda), ncol=length(hm1))
rownames(rowNAs) <- lambda
colnames(rowNAs) <- colnames(hm1)
hm2 <- rbind.data.frame(hm1, rowNAs)

#reorder data in wavelength order
lamnum <- rownames(hm2)
lamnum <- sub("nm", "", lamnum)
lamnum <- as.numeric(lamnum)
#assign the numeric wavelength as column and row names
rownames(hm2) <- lamnum
colnames(hm2) <- lamnum
#order the df in decending wavelength order
new_df <- hm2[ order(as.numeric(row.names(hm2))), ]
new_df <- new_df[,order(as.numeric(colnames(new_df)))]

#Hide upper triangle
hmfinal<-new_df
hmfinal[upper.tri(new_df, diag=TRUE)]<-""
#convert to form needed for heatmap (numeric matrix)
hmfinal <- as.matrix(sapply(hmfinal, as.numeric))
    #hmfinal<-data.matrix(hmfinal)

#write.csv(hmfinal, "PLSR_allsites_corrcoeff.csv")


#now, ready for heatmap graphing!
labvec <- c(rep(NA, 426))
labvec[c(4,44,84,124,164,204,244,284,324,364,404)] <- c(400,600,800,1000,1200,1400,1600,1800,2000,2200,2400)

#create color ramp for heat map
jet.colors <- colorRampPalette(c("#00007F", "blue", "#007FFF", "cyan", 
                                 "#7FFF7F", "yellow", "#FF7F00", "red", "#7F0000"))

lwid = c(1.5,4)
lhei = c(1.5,4)
#to put key underneath heatmap
lmat = rbind(4:3,2:1)


#create heat map of correlation coefficients for all 2-band indices
#heatmap.2((hmfinal),dendrogram='none', Rowv=FALSE, na.rm=TRUE, distfun=FALSE,
        #  Colv=FALSE,trace='none', col=jet.colors, labRow=labvec, 
        #  labCol=labvec, srtCol=0, adjCol=c(0,-25),cexRow = 1.1, cexCol = 1.1,
        #  lmat = lmat, lwid = lwid, lhei = lhei, main="All Sites",
        #  key=FALSE)

heatmap.2((hmfinal),dendrogram='none', Rowv=FALSE, na.rm=TRUE, distfun=FALSE,
          Colv=FALSE,trace='none', col=jet.colors, labRow=labvec, 
          labCol=labvec, srtCol=0,cexRow = 1.1, cexCol = 1.1, offsetRow= -28,
          lmat = lmat, lwid = lwid, lhei = lhei, main="Tropical Sites",
          key=TRUE, density.info="histogram",denscol = "black", key.title = NA,
          key.xlab = "Coefficient", key.ylab = "Count",
          xlab= "Wavelength Band 1 (nm)", ylab="Wavelength Band 2 (nm)")

#saved as .png image; width: 652 height: 471;

#######################################################
#####################VIP heatmap#######################
#######################################################
goodVIP <- VIP.frame[,-1]

#picking up from line 32
avgVIP <- matrix(NA, nrow=nrow(goodVIP), ncol=1)

#calculate the average VIP value for all of the "good model" runs
avgVIP <- rowMeans(goodVIP)
avgVIP <- as.data.frame(avgVIP)

#cbind band1, band2, and avg coeff into a new df
dfvals <- cbind.data.frame(twobands,avgVIP$avgVIP)
names(dfvals)[names(dfvals) == "avgVIP$avgVIP"] <- "avgVIP"
names(dfvals)[names(dfvals) == "1"] <- "band1"
names(dfvals)[names(dfvals) == "2"] <- "band2"

#reshape data so that in corr matrix structure with band 1 as columns and band 2 as rows
hmdata <- acast(dfvals, band1~band2, value.var="avgVIP")
hmdata <- as.data.frame(hmdata)

#add the wavelength regions that were excluded
#create vector of excluded bands
lambda1 <- seq(385,405, by=5)
lambda2 <- seq(1335,1455, by=5)
lambda3 <- seq(1795,2000, by=5)
lambda4 <- seq(2445, 2510, by=5)
lambda <- c(lambda1, lambda2, lambda3, lambda4)
lambda <- sub("$", "nm", lambda) 
#add "NA" columns
colNAs <-matrix(NA, nrow=length(hmdata), ncol=length(lambda))
colnames(colNAs) <- lambda
hm1 <- cbind.data.frame(hmdata, colNAs)
#add "NA" rows
rowNAs <- matrix(NA, nrow=length(lambda), ncol=length(hm1))
rownames(rowNAs) <- lambda
colnames(rowNAs) <- colnames(hm1)
hm2 <- rbind.data.frame(hm1, rowNAs)

#reorder data in wavelength order
lamnum <- rownames(hm2)
lamnum <- sub("nm", "", lamnum)
lamnum <- as.numeric(lamnum)
#assign the numeric wavelength as column and row names
rownames(hm2) <- lamnum
colnames(hm2) <- lamnum
#order the df in decending wavelength order
new_df <- hm2[ order(as.numeric(row.names(hm2))), ]
new_df <- new_df[,order(as.numeric(colnames(new_df)))]

#Hide upper triangle
hmfinal<-new_df
hmfinal[upper.tri(new_df, diag=TRUE)]<-""
#convert to form needed for heatmap (numeric matrix)
hmfinal <- as.matrix(sapply(hmfinal, as.numeric))

#write.csv(hmfinal, "./3x3buff/NDVI_PLSR/try2/VIPheatmap_all.csv")

#for each ecosystem saved as .png image; width: 652 height: 471;


heatmap.2((hmfinal),dendrogram='none', Rowv=FALSE, na.rm=TRUE, distfun=FALSE,
          Colv=FALSE,trace='none', col=jet.colors, labRow=labvec, 
          labCol=labvec, srtCol=0,cexRow = 1.1, cexCol = 1.1,offsetRow= -28,
          lmat = lmat, lwid = lwid, lhei = lhei,
          key=TRUE, density.info="histogram",denscol = "black", key.title = NA,
          key.xlab = "VIP score", key.ylab = "Count")
#title("a. All Sites", line=-2.5, adj=0.12, font.main=1)
#text(0.095,0.42, labels="Wavelength Band 1 (nm)", srt=90)
#title(xlab="Wavelength Band 2 (nm)", line = -0.01)
#title("Wavelength Band 2 (nm)",line=-19.4, cex.main=0.965, font.main=1)
#for each ecosystem saved as .png image; width: 652 height: 471;


##look at only values that fall within 3 stdev from the mean
outliers <- boxplot(hmfinal)$out
avghm <- mean(hmfinal, na.rm = TRUE)
sdhm <- std(hmfinal, na.rm=TRUE)
cut_off <- sdhm * 3
lower <- avghm - cut_off
upper <- avghm + cut_off
min(hmfinal, na.rm=TRUE)



hmhigh <- matrix(NA, nrow=nrow(hmfinal), ncol=ncol(hmfinal))

pb <- txtProgressBar(min = 2, max = 181476, style = 3)

for (i in 1:length(hmfinal)){
  for(j in 1:ncol(hmfinal)){
    hmval <- hmfinal[i,j] 
    if (hmval > upper ){
      hmhigh[i,j] <- hmfinal[i,j]
    } else{
      hmhigh[i,j] <- "NA"
    }
  }
  setTxtProgressBar(pb, i)
}

break1 <- seq(0.03820471, avghm, length=100)
break2 <- seq(avghm+.001, avghm + (sdhm), length=100)
break3 <- seq(max(break2)+.001, avghm + (sdhm*2), length=100)
break4 <- seq(max(break3)+.001, avghm + (sdhm*3), length=100)
break5 <- seq(max(break4)+.001, avghm + (sdhm*4), length=100)
break6 <- seq(max(break5)+.001, 3.845405, length=100)

colors_breaks = c(break1, break2, break3, break4, break5, break6)

jet.colors <- colorRampPalette(c("#00007F", "#007FFF", "cyan", 
                                 "yellow", "#FF7F00", "#7F0000"))

heatmap.2((hmfinal),dendrogram='none', Rowv=FALSE, na.rm=TRUE, distfun=FALSE,
          Colv=FALSE,trace='none',breaks=colors_breaks, col=jet.colors, labRow=labvec, 
          labCol=labvec, srtCol=0, adjCol=c(0,-25),cexRow = 1.1, cexCol = 1.1,
          lmat = lmat, lwid = lwid, lhei = lhei, main="All Sites",
          key=FALSE)
