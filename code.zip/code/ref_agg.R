#######calculate sample-averaged hyperspec reflectance and output file to "3mbuff" folder###########
#setwd
setwd("Z:/SRER/Martha/NEONpaper/data/dataSept2020/extract_hyperspec")
flights <- read.csv("Z:/SRER/Martha/NEONpaper/AOPreflectance/kml/flightline.csv")
flights <- flights[,c(4,9,10)]

shp <- readOGR("Z:/SRER/Martha/NEONpaper/data/dataSept2020/shp_files", "zone5N")
samples <- as.data.frame(shp)
samples <- samples[,c(1,5,16)]
#SRER
#shp <- readOGR("Z:/SRER/Martha/NEONpaper/AOPreflectance/3mbuff", "SRER")
#samples <- as.data.frame(shp)
#names(samples)[names(samples) == "id"] <- "samplID"
#samples$indvdID <- samples$samplID
#samples$clipID <- rep(NA, nrow(samples))
#samples <- samples[,-2]

#load reflectance data. Will need to do this individually for each site after "extract_hyperspec.py" is run on each site 
ref <- read.csv("zone5N_points.csv")
#SRER
#ref <- read.csv("SRER_points.csv")

#caculate 3x3m buffer averaged reluctance readings
avg <- aggregate(ref, by=list(ref$id, ref$siteID, ref$raster), FUN=mean)
avg <- avg[,-c(4,5,6,7)]
avg2 <- avg[,c(1:3,430,431,4:429)]

names(avg2)[names(avg2) == "Group.1"] <- "samplID"
names(avg2)[names(avg2) == "Group.2"] <- "siteID"
names(avg2)[names(avg2) == "Group.3"] <- "raster"
names(avg2)[names(avg2) == "x"] <- "avgEasting"
names(avg2)[names(avg2) == "y"] <- "avgNorthing"
#create logID column
avg2$logIDs <- substr(avg2$raster, 28,33)
#remove observations with no reflectance values
avg2 <- avg2[complete.cases(avg2[,22:25]),]

#add 'indvID' to the data frame
avg2 <- merge(samples, avg2, by="samplID")
#keep only the observations for the flightlines IDed
#woody samples
woody <- merge(avg2, flights, by=c("indvdID", "logIDs"))
names(woody)[names(woody) == "clipID.x"] <- "clipID"
woody <- woody[,-435]
#herb samples
herbs <- merge(avg2, flights, by=c("clipID", "logIDs")) 
names(herbs)[names(herbs) == "indvdID.x"] <- "indvdID" 
herbs <- herbs[,-435]
final <- rbind.data.frame(woody,herbs)

#final_all <- final
final_all <- rbind.data.frame(final_all, final)


getwd()
write.csv(final_all, "puum.csv")
#######after the above code is run###########
#######rename column headers to "band#", combine sample-averaged hyperspec reflectance from all sites, and combine reflectance values with descriptive variables.###########

#create new column names of just band #s
bands <- rep("band", 426)
num <- seq(from = 1, to = 426, by=1)
refband <- paste(bands,num, sep="")


setwd("Z:/SRER/Martha/NEONpaper/data/dataSept2020/extract_hyperspec")
#create a list of the csv files in the folder
csvfiles = list.files(".", pattern = "*.csv")

#function to reformat the reflectance values and assign band#s as column names
format_ref <- function(x){
  tmp = read.csv(x)
  site <- tmp[,2:4]
  ref <- tmp[,5:430]
  colnames(ref) <- refband
  siteref <- cbind(site,ref)
  return(siteref)
}


#apply the "format_ref" function over the csv files
ref_tmp <- lapply(csvfiles, format_ref)
#Bind rows together
indices <- do.call(rbind, ref_tmp)

#load the descriptive variables
setwd("Z:/SRER/Martha/NEONpaper/AOPreflectance/")
refdata <- read.csv("./plantclip_locs/allsites_clips.csv")
descvars <- refdata[,c(7,3,8:25)]

reflect <- merge(descvars, indices, by="samplID")

#write the dataframe
write.csv(reflect, "./3mbuff/allsites.csv")
