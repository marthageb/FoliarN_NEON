#add the necessary meta-data to the topo/BRDF corrected .h5 files 

#python hyperspec_info.py
import numpy as np
import h5py as h5
from os import listdir
from os.path import join


read_dir = 'Z:/SRER/Martha/NEONpaper/topo_brdf_prac/orig_hdf/other'
write_dir = 'Z:/SRER/Martha/NEONpaper/topo_brdf_prac/output/other'

for file in listdir(read_dir):
    if not file.endswith('.h5'):
        continue
    hyper_read = h5.File(join(read_dir,file), 'r')
    hyper_write = h5.File(join(write_dir,file), 'a')
    
    #get the site ID
    parts = file.split("_")
    siteID = parts[2]
    
    #create the group hierarcy in the output dataset
    hyper_write.create_group(f'{siteID}/Reflectance/Metadata/Spectral_Data')
    
    #get the wavelength dataset
    wavelength = hyper_read[f'{siteID}/Reflectance/Metadata/Spectral_Data/Wavelength']
    #copy the wavelength to the hdf write file
    hyper_write.create_dataset(f'{siteID}/Reflectance/Metadata/Spectral_Data/Wavelength', data=wavelength)
    
    #get the mapinfo
    mapinfo = hyper_read[f'{siteID}/Reflectance/Metadata/Coordinate_System/Map_Info']
    hyper_write.create_dataset(f'{siteID}/Reflectance/Metadata/Coordinate_System/Map_Info', data=mapinfo)
    
    #get attributes of the reflectance dataset
        ##ISSUE WITH THE SPATIAL EXTENT OF PUUM SITES; NROW and NCOL values swithced. Need to manually define spatial extent.
    refldata_read = hyper_read[f'{siteID}/Reflectance/Reflectance_Data']
    spatial_extent = refldata_read.attrs["Spatial_Extent_meters"]
    
    refldata_write = hyper_write['Topo/Correction']
    refldata_write.attrs["Spatial_Extent_meters"] = spatial_extent
        ##PUUM 221413
            #spatial_extent[1]=254428.0
            #spatial_extent[2]=2158387.0
        ##PUUM 224406
            #spatial_extent[1]=257138.0
            #spatial_extent[2]=2158070.0
        ##PUUM 224915
            #spatial_extent[1]=257552.0
            #spatial_extent[2]=2158696.0
        ##PUUM 204655
            #spatial_extent[1]=266532.0
            #spatial_extent[2]=2158523.0
        ##PUUM 193740
            #spatial_extent[1]=264312.0
            #spatial_extent[2]=2158286.0
    #Extract bad band windows
    refl_read = hyper_read[f'{siteID}/Reflectance']
    badband1 = (refl_read.attrs["Band_Window_1_Nanometers"])
    badband2 = (refl_read.attrs["Band_Window_2_Nanometers"])
    
    refl_write = hyper_write[f'{siteID}/Reflectance']
    refl_write.attrs["Band_Window_1_Nanometers"] = badband1
    refl_write.attrs["Band_Window_2_Nanometers"] = badband2
    
    #Extract projection information
    proj = hyper_read[f'{siteID}/Reflectance/Metadata/Coordinate_System/Proj4']
    hyper_write.create_dataset(f'{siteID}/Reflectance/Metadata/Coordinate_System/Proj4', data=proj)
    
    epsg = hyper_read[f'{siteID}/Reflectance/Metadata/Coordinate_System/EPSG Code']
    hyper_write.create_dataset(f'{siteID}/Reflectance/Metadata/Coordinate_System/EPSG Code', data=epsg)
    
    hyper_write.close
    hyper_read.close