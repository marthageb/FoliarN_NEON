########CALCULATE META-DATA FOR EACH SITE INCLUDING Green Leaf Index (GLI) FROM HIGH-RESOLUTION RGB IMAGERY, Leaf Area Index (LAI) FROM HYPERSPECTRAL IMAGERY, 
########AND SAMPLE PROXIMITY BASED ON SAMPLE LOCATIONS
library(rgdal)
library(sf)
library(raster)
library(rgeos)
library(stringr)
library(sp)
library(dplyr)


####CALCUALTE GLI####
setwd("D:/martha/NEONpaper/AOPreflectance/3mbuff")

#load coordinates for woody and herbaceous samples
woody <- read.csv("D:/martha/NEONpaper/data/dataSept2020/woody_foliarchem_locations.csv")
woody <- woody[,c(3,4,15,5:14,16:21)]

herb <- read.csv("D:/martha/NEONpaper/data/dataSept2020/herbs_foliarchem_locations.csv")
herb <- herb[,c(3,14,2,4:13,15,24:28)]

plants <- rbind.data.frame(woody, herb)

#load shape file of 3x3m plots
zone <- readOGR("D:/martha/NEONpaper/AOPreflectance/3mbuff/zone19N.shp")
plot(zone)

#subset plant samples that are in the loaded shape file
site_plants <- subset(plants, sampleID %in% zone$id)
zone_sites <- unique(site_plants$siteID)

#list the RGB files for sites
tiles <- list.files(paste("D:/martha/NEONpaper/RGB/", zone_sites, sep=""), full.names = TRUE)

#function to read in the RGB raster stack, crop the plots to the raster extent, then crop the RGB to the plot area, calculate GLI, then calculate average GLI for the 3x3 plot area 
gli_fxn <- function(x){
  #load RGB image
  rgb <- stack(x)
  print(x)
  #crop the plots to the raster layer extent
  plots <- crop(zone, extent(rgb))
  
  #then crop the raster layer to this area
  rast <- crop(rgb, extent(plots))
  
  #calculate the GLI
  gli <- ((rast[[2]]-rast[[1]])+(rast[[2]]+rast[[3]])) / ((2*rast[[2]]) + rast[[1]] + rast[[3]])
  
  #calcualte the average gli for the plot areas
  r.vals <- extract(gli, plots)
  
  # Use list apply to calculate mean for each polygon
  r.mean <- lapply(r.vals, FUN=mean)
  
  #get plotIDs for each average
  gli_avg <- unlist(r.mean)
  final <- cbind.data.frame((as.data.frame(plots)), gli_avg)        
  return(final)
}

gli_plots <- lapply(tiles, gli_fxn) %>% bind_rows()

#whenever id is duplicated, calculate the average gli
gli_final <- gli_plots %>% group_by(id) %>% summarize(gli_avg = mean(gli_avg, na.rm=TRUE))
colnames(gli_final) <- c("sampleID", "gli_avg")

#Combine average GLI with the rest of the data
gli_all <- merge(site_plants, gli_final, by="sampleID")

#combine with GLI averages from other zones
#all <- gli_all #for the 1st zone
all <- rbind.data.frame(all, gli_all)


#write.csv(all, "D:/martha/NEONpaper/data/dataSept2020/GLI.csv")

summ <- all %>% group_by(siteID) %>% summarize(avg = mean(gli_avg, na.rm=TRUE), gli_min = min(gli_avg, na.rm=TRUE), gli_max = max(gli_avg, na.rm=TRUE))
write.csv(summ,"C:/Users/farellam/Documents/FoliarN_NEON/gli_summary.csv")


hist(all$gli_avg)
summary(all$gli_avg)




####CALCULATE LAI####
#load reflectance data (input for the PLSR models)
####CALCULATE AVERAGE LAI according to NEON's calculation####
data <- read.csv("c:/Users/farellam/Documents/FoliarN_NEON/data/oldanalysis.csv")

#calcualte save and LAI
data$savi <- ((data$X850nm - data$X650nm) * 1.5) / (data$X850nm + data$X650nm + 0.5)
data$lai <- -1/0.60 * (log((0.82-data$savi)/0.78))

summary(data$lai)
hist(data$lai)

summ <- data %>% group_by(siteID) %>% summarize(lai_avg = mean(lai, na.rm=TRUE), lai_min = min(lai, na.rm=TRUE), lai_max = max(lai, na.rm=TRUE))
write.csv(summ,"C:/Users/farellam/Documents/FoliarN_NEON/lai_summary.csv")


#######SAMPLE PROXIMITY ANALYSIS######
#define function to calcualte the percentage of sample points that are closer than 3m for each site
dist_fxn <- function(x){
  print(x)
  site <- subset(zone, siteID== x)
  #calculate distance between points
  # longlat = FALSE returns Euclidean distance; TRUE returns GreatCircle distance (is a little more accurate especially when there's more than one UTM zone being analyzed)
  dist <- sp::spDists(site,longlat = FALSE)
  #set all 0 vals to NA
  dist[dist == 0] <- NA
  #to see points that might fall within the same extracted hyperspectral area (3m), set all values greater than 3m to NA
  dist[dist > 3] <- NA
  #colnames(dist) <- str_remove(zone.df$indvdID, pattern="NEON.PLA.D20.PUUM.")
  #row.names(dist) <- colnames(dist)
  
  #calcualte total number of unique pairs of samples at a site
  site.df <- subset(zone.df, siteID == x)
  samples <- as.numeric(nrow(site.df))
  unique <- samples*(samples-1)/2
  
  #define the number of overlapped samples 
  na <- sum(is.na(dist))
  totalnum <- nrow(dist) * ncol(dist)
  notna <- (totalnum - na) / 2
  
  #calcualte percentage of overlapped samples
  overlap <- (notna/unique) * 100
  
  output <- cbind.data.frame(x, overlap, unique, notna)
  colnames(output) <- c('site', "per_less3m", "total_pairs", "close_pairs")
  return(output)
}


#load the shape file for each zone
zone <- readOGR("C:/Users/farellam/Documents/FoliarN_NEON/data/shp_files/zone19N.shp")
zone.df <- as.data.frame(zone)
plot(zone)
str(zone)

#get a list of all sites in that zone
allsites <- unique(zone.df$siteID)


#apply the function across all sites
prox <- lapply(allsites, dist_fxn)
final <- do.call("rbind",prox)

#combine with results from other zones
#final.all <- final #for the first zone
final.all <- rbind.data.frame(final.all, final) #for all zones after the 1st one

#save output
write.csv(final.all, "C:/Users/farellam/Documents/FoliarN_NEON/Results/sample_prox.csv")
